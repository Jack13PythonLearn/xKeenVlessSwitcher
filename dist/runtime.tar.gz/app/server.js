const http = require('http');
const https = require('https');
const { URL } = require('url');
const net = require('net');
const fs = require('fs');
const path = require('path');
const { exec, execSync, spawn } = require('child_process');
const zlib = require('zlib');
const os = require('os');
const { createSubscriptionManager, publicSubscription, subscriptionUrl } = require('./lib/subscriptions');
const { mergeChanges } = require('./lib/data-merge');
const { connectionName } = require('./lib/connection-name');
const { createRoutingSync, SOURCES: routingSources, v2flyLists: routingSourceLists } = require('./lib/routing-sync');
const { applyRoutingReplacements } = require('./lib/routing-replacements');
const dataSnapshots = new WeakMap();
const {createQueue, atomicWrite, applyFiles} = require('./lib/operations');
const applyQueue = createQueue();
const {validateIds}=require('./lib/validation');
let automationGeneration = 0;


const DATA_DIR = process.env.XKEEN_DATA_DIR || path.join(__dirname, 'data');
const DATA_FILE = path.join(DATA_DIR, 'profiles.json');
const FAILOVER_LOG_FILE = path.join(DATA_DIR, 'failover_history.json');
const AUTOFAILOVER_LOG_FILE = path.join(DATA_DIR, 'autofailover_history.json');
const PUBLIC_DIR = path.join(__dirname, 'public');
const healthStore=require('./lib/health-store').createHealthStore(path.join(DATA_DIR,'health.json'));
process.once('exit',()=>{try {healthStore.flush();}catch {}});
if(require.main===module) process.once('SIGTERM',()=>{try {healthStore.flush();}finally {process.exit(0);}});

let isUpdatingApp = false;
const {trustedOrigin} = require('./lib/request-origin');

// Ensure data directory exists
if (!fs.existsSync(path.dirname(DATA_FILE))) {
  fs.mkdirSync(path.dirname(DATA_FILE), { recursive: true });
}

// Read application version from package.json
let appVersion = '2.0.2';
let updateRepository = '';
try {
  const pkgPath = path.join(__dirname, 'package.json');
  if (fs.existsSync(pkgPath)) {
    const pkg = JSON.parse(fs.readFileSync(pkgPath, 'utf8'));
    if (pkg.version) appVersion = pkg.version;
    if (/^[\w.-]+\/[\w.-]+$/.test(pkg.updateRepository || '')) updateRepository = pkg.updateRepository;
  }
} catch (e) {
  console.warn('Could not read package.json version:', e.message);
}

// In-memory service state & error cache
let lastServiceStatus = {
  status: 'unknown', // 'running' | 'stopped' | 'error' | 'unknown'
  output: '',
  error: '',
  timestamp: null,
  command: ''
};

// Default system routing 1: "Всё через VPN"
const SYSTEM_ROUTING_ALL_VPN = {
  id: 'routing_all_vpn',
  name: 'Всё через VPN',
  description: 'Весь интернет-трафик направляется через активное подключение',
  isSystem: true,
  content: JSON.stringify({
    routing: {
      domainStrategy: 'IPIfNonMatch',
      rules: [
        {
          type: 'field',
          ip: [
            'geoip:private'
          ],
          outboundTag: 'direct'
        }
      ]
    }
  }, null, 2),
  createdAt: '2026-01-01T00:00:00.000Z'
};

// Default system routing 2: "Всё через VPN кроме РФ"
const SYSTEM_ROUTING_EXCEPT_RU = {
  id: 'routing_except_ru',
  name: 'Всё через VPN кроме РФ',
  description: 'Весь трафик через VPN, кроме российских сайтов и IP-адресов (напрямую)',
  isSystem: true,
  content: JSON.stringify({
    routing: {
      domainStrategy: 'IPIfNonMatch',
      rules: [
        {
          type: 'field',
          inboundTag: [
            'redirect',
            'tproxy'
          ],
          outboundTag: 'block',
          network: 'udp',
          port: '135,137,138,139'
        },
        {
          type: 'field',
          inboundTag: [
            'redirect',
            'tproxy'
          ],
          outboundTag: 'direct',
          protocol: [
            'bittorrent'
          ]
        },
        {
          type: 'field',
          inboundTag: [
            'redirect',
            'tproxy'
          ],
          outboundTag: 'direct',
          domain: [
            'regexp:^([\\w\\-\\.]+\\.)ru$',
            'regexp:^([\\w\\-\\.]+\\.)su$',
            'regexp:^([\\w\\-\\.]+\\.)xn--p1ai$',
            'regexp:^([\\w\\-\\.]+\\.)xn--p1acf$',
            'regexp:^([\\w\\-\\.]+\\.)xn--80asehdb$',
            'regexp:^([\\w\\-\\.]+\\.)xn--c1avg$',
            'regexp:^([\\w\\-\\.]+\\.)xn--80aswg$',
            'regexp:^([\\w\\-\\.]+\\.)xn--80adxhks$',
            'regexp:^([\\w\\-\\.]+\\.)moscow$',
            'regexp:^([\\w\\-\\.]+\\.)xn--d1acj3b$',
            'ext:geosite_v2fly.dat:category-gov-ru',
            'ext:geosite_v2fly.dat:yandex',
            'ext:geosite_v2fly.dat:vk',
            'ext:geosite_v2fly.dat:steam'
          ]
        },
        {
          type: 'field',
          inboundTag: [
            'redirect',
            'tproxy'
          ],
          outboundTag: 'direct',
          ip: [
            'geoip:private',
            'ext:geoip_zkeenip.dat:ru'
          ]
        },
        {
          type: 'field',
          inboundTag: [
            'redirect',
            'tproxy'
          ],
          outboundTag: 'vless-reality',
          network: 'tcp,udp'
        }
      ]
    }
  }, null, 2),
  createdAt: '2026-01-01T00:00:00.000Z'
};

// Auto-detect existing xray/xkeen config paths on router
function detectConfigPaths() {
  const possibleDirs = [
    '/opt/etc/xray/configs',
    '/opt/etc/xray/config',
    '/opt/etc/xray',
    '/opt/etc/xkeen/configs',
    '/opt/etc/xkeen/config',
    '/opt/etc/xkeen',
    '/opt/etc/v2ray/configs',
    '/opt/etc/v2ray/config',
    '/opt/etc/v2ray'
  ];

  let detectedDir = '/opt/etc/xray/configs';
  for (const dir of possibleDirs) {
    if (fs.existsSync(dir)) {
      try {
        if (fs.statSync(dir).isDirectory()) {
          detectedDir = dir;
          break;
        }
      } catch (e) {}
    }
  }

  let outboundPath = path.join(detectedDir, '05_outbounds.json');
  let routingPath = path.join(detectedDir, '05_routing.json');

  if (fs.existsSync(detectedDir)) {
    try {
      const files = fs.readdirSync(detectedDir);

      // Look for outbound file
      const obFile = files.find(f => /outbounds?\.jsonc?$/i.test(f))
        || files.find(f => /0[34567]_outbounds?\.jsonc?$/i.test(f));
      if (obFile) {
        outboundPath = path.join(detectedDir, obFile);
      } else {
        for (const file of files) {
          if (!file.endsWith('.json') && !file.endsWith('.jsonc')) continue;
          try {
            const content = fs.readFileSync(path.join(detectedDir, file), 'utf8');
            if (content.includes('"outbounds"') || content.includes('"outbound"')) {
              outboundPath = path.join(detectedDir, file);
              break;
            }
          } catch (e) {}
        }
      }

      // Look for routing file
      const rtFile = files.find(f => /0[234567]_routing\.jsonc?$/i.test(f))
        || files.find(f => /routing\.jsonc?$/i.test(f))
        || files.find(f => /routes?\.jsonc?$/i.test(f));
      if (rtFile) {
        routingPath = path.join(detectedDir, rtFile);
      } else {
        for (const file of files) {
          if (!file.endsWith('.json') && !file.endsWith('.jsonc')) continue;
          try {
            const content = fs.readFileSync(path.join(detectedDir, file), 'utf8');
            if (content.includes('"routing"') || (content.includes('"rules"') && !content.includes('"outbounds"'))) {
              routingPath = path.join(detectedDir, file);
              break;
            }
          } catch (e) {}
        }
      }
    } catch (err) {
      console.error('Error scanning config directory:', err);
    }
  }

  return { outboundPath, routingPath };
}

// Strip single-line (//) and multi-line (/* */) comments and trailing commas from JSON string
function stripJsonComments(str) {
  if (!str) return '';
  const noComments = str.replace(/("(\\u[a-zA-Z0-9]{4}|\\[^u]|[^\\"])*")|(\/\*[\s\S]*?\*\/)|(\/\/[^\r\n]*)/g, (match, stringToken, p2, multiComment, singleComment) => {
    if (stringToken) return stringToken;
    if (singleComment || multiComment) return '';
    return match;
  });
  return noComments.replace(/,\s*([}\]])/g, '$1');
}

function parseJsonWithComments(str) {
  const stripped = stripJsonComments(str);
  return JSON.parse(stripped);
}

// Parse VLESS URL to Outbound JSON and metadata
function parseVlessUrl(urlStr) {
  if (!urlStr || typeof urlStr !== 'string') {
    throw new Error('Ссылка подключения не указана');
  }
  const cleanStr = urlStr.trim();
  if (!cleanStr.startsWith('vless://')) {
    throw new Error('Поддерживаются ссылки формата vless://');
  }

  const u = new URL(cleanStr);
  const id = decodeURIComponent(u.username);
  const address = (u.hostname || '').replace(/^\[|\]$/g, '');
  const port = parseInt(u.port, 10);
  if (!id || !address || !port) {
    throw new Error('Некорректная ссылка VLESS: отсутствуют обязательные параметры (UUID, адрес, порт)');
  }

  let rawName = u.hash ? u.hash.replace(/^#/, '') : '';
  let name = '';
  try {
    name = decodeURIComponent(rawName).trim();
  } catch (e) {
    name = rawName.trim();
  }
  if (!name) {
    name = `VLESS - ${address}:${port}`;
  }

  const sp = u.searchParams;
  const type = (sp.get('type') || 'tcp').toLowerCase();
  const security = (sp.get('security') || 'none').toLowerCase();
  const encryption = sp.get('encryption') || 'none';
  const flow = sp.get('flow') || '';
  const pbk = sp.get('pbk') || '';
  const fp = sp.get('fp') || 'chrome';
  const sni = sp.get('sni') || '';
  const sid = sp.get('sid') || '';
  const spx = sp.get('spx') || '/';
  const serviceName = sp.get('serviceName') || sp.get('service_name') || '';
  if (!['tcp', 'raw', 'grpc', 'ws', 'xhttp'].includes(type) || !['none', 'tls', 'reality'].includes(security)) {
    throw new Error('Неподдерживаемый транспорт или защита VLESS');
  }
  if (security === 'reality' && !pbk) throw new Error('Не указан публичный ключ Reality');

  // Stream settings
  const streamSettings = {
    network: type,
    security: security
  };

  if (security === 'reality') {
    streamSettings.realitySettings = {
      publicKey: pbk,
      fingerprint: fp,
      serverName: sni,
      shortId: sid,
      spiderX: spx
    };
  } else if (security === 'tls') {
    streamSettings.tlsSettings = {
      serverName: sni,
      fingerprint: fp
    };
    if (sp.get('alpn')) streamSettings.tlsSettings.alpn = sp.get('alpn').split(',');
    if (sp.get('pcs')) streamSettings.tlsSettings.pinnedPeerCertSha256 = sp.get('pcs');
    if (['1', 'true'].includes(sp.get('allowInsecure') || sp.get('insecure'))) streamSettings.tlsSettings.allowInsecure = true;
  }

  if (type === 'grpc') {
    streamSettings.grpcSettings = {
      serviceName: serviceName,
      multiMode: sp.get('mode') === 'multi'
    };
  } else if (type === 'ws') {
    const wsPath = sp.get('path') || '/';
    streamSettings.wsSettings = {
      path: wsPath,
      headers: {
        Host: sp.get('host') || sni || ''
      }
    };
  } else if (type === 'xhttp') {
    streamSettings.xhttpSettings = { path: sp.get('path') || '/', host: sp.get('host') || '', mode: sp.get('mode') || 'auto' };
    if (sp.has('extra')) throw new Error('Параметр XHTTP extra пока не поддерживается');
  } else if (type === 'tcp' || type === 'raw') {
    const headerType = sp.get('headerType');
    if (headerType && headerType !== 'none') {
      streamSettings.tcpSettings = {
        header: {
          type: headerType
        }
      };
    }
  }

  const tag = security === 'reality' ? 'vless-reality' : (security !== 'none' ? `vless-${security}` : 'vless');

  const outboundJsonObj = {
    outbounds: [
      {
        tag: tag,
        protocol: 'vless',
        settings: {
          vnext: [
            {
              address: address,
              port: port,
              users: [
                {
                  id: id,
                  flow: flow,
                  encryption: encryption,
                  level: 0
                }
              ]
            }
          ]
        },
        streamSettings: streamSettings
      },
      {
        tag: 'direct',
        protocol: 'freedom'
      },
      {
        tag: 'block',
        protocol: 'blackhole',
        settings: {
          response: {
            type: 'http'
          }
        }
      }
    ]
  };

  return {
    name,
    serverAddress: address,
    serverPort: port,
    protocol: 'vless',
    network: type,
    security: security,
    sni: sni,
    outboundJson: JSON.stringify(outboundJsonObj, null, 4)
  };
}

// Extract connection metadata from arbitrary outbound JSON
function extractOutboundMetadata(outboundContent) {
  let serverAddress = '';
  let serverPort = null;
  let protocol = 'vless';
  let network = 'tcp';
  let security = 'none';
  let sni = '';

  try {
    const clean = stripJsonComments(outboundContent);
    const parsed = JSON.parse(clean);
    const list = Array.isArray(parsed.outbounds) ? parsed.outbounds : [parsed];
    for (const ob of list) {
      if (!ob || ob.tag === 'direct' || ob.tag === 'block') continue;
      if (ob.protocol) protocol = ob.protocol;
      if (ob.settings) {
        if (ob.settings.vnext && ob.settings.vnext[0]) {
          serverAddress = ob.settings.vnext[0].address || '';
          serverPort = ob.settings.vnext[0].port || null;
        } else if (ob.settings.servers && ob.settings.servers[0]) {
          serverAddress = ob.settings.servers[0].address || '';
          serverPort = ob.settings.servers[0].port || null;
        } else if (ob.protocol === 'hysteria' && ob.settings.address) {
          serverAddress = ob.settings.address;
          serverPort = ob.settings.port || null;
        } else if (ob.settings.peers && ob.settings.peers[0] && ob.settings.peers[0].endpoint) {
          const ep = String(ob.settings.peers[0].endpoint).trim();
          const lastColon = ep.lastIndexOf(':');
          if (lastColon !== -1) {
            serverAddress = ep.substring(0, lastColon).replace(/^\[|\]$/g, '');
            serverPort = parseInt(ep.substring(lastColon + 1), 10) || null;
          } else {
            serverAddress = ep;
          }
        }
      }
      if (ob.streamSettings) {
        if (ob.streamSettings.network) network = ob.streamSettings.network;
        if (ob.streamSettings.security) security = ob.streamSettings.security;
        if (ob.streamSettings.realitySettings && ob.streamSettings.realitySettings.serverName) {
          sni = ob.streamSettings.realitySettings.serverName;
        } else if (ob.streamSettings.tlsSettings && ob.streamSettings.tlsSettings.serverName) {
          sni = ob.streamSettings.tlsSettings.serverName;
        }
      } else if (protocol === 'wireguard') {
        network = 'udp';
      }
      if (serverAddress) break;
    }
  } catch (e) {}

  return { serverAddress, serverPort, protocol, network, security, sni };
}

// Helper: Measure TCP handshake latency (ping in ms) to host:port
function measureTcpLatency(host, port, timeout = 3500) {
  return new Promise((resolve) => {
    if (!host || !port) {
      return resolve({ ok: false, error: 'Хост или порт не указаны' });
    }
    const cleanHost = String(host).trim().replace(/^\[|\]$/g, '');
    const numPort = parseInt(port, 10);
    if (!cleanHost || isNaN(numPort) || numPort <= 0 || numPort > 65535) {
      return resolve({ ok: false, error: 'Некорректный хост или порт' });
    }
    const t0 = Date.now();
    const socket = new net.Socket();
    let settled = false;

    socket.setTimeout(timeout);

    socket.on('connect', () => {
      if (!settled) {
        settled = true;
        const latency = Date.now() - t0;
        socket.destroy();
        resolve({ ok: true, latency });
      }
    });

    socket.on('timeout', () => {
      if (!settled) {
        settled = true;
        socket.destroy();
        resolve({ ok: false, error: 'Таймаут соединения' });
      }
    });

    socket.on('error', (err) => {
      if (!settled) {
        settled = true;
        socket.destroy();
        resolve({ ok: false, error: err.message || 'Недоступен' });
      }
    });

    try {
      socket.connect(numPort, cleanHost);
    } catch (e) {
      if (!settled) {
        settled = true;
        resolve({ ok: false, error: e.message || 'Ошибка сокета' });
      }
    }
  });
}

// Helper: Locate Xray binary on router / host system
let cachedXrayPath = undefined;
function findXrayPath() {
  if (cachedXrayPath !== undefined) return cachedXrayPath;
  const candidates = [
    '/opt/sbin/xray',
    '/opt/bin/xray',
    '/usr/sbin/xray',
    '/usr/bin/xray',
    '/usr/local/bin/xray'
  ];
  for (const c of candidates) {
    try {
      if (fs.existsSync(c)) {
        cachedXrayPath = c;
        return c;
      }
    } catch (e) {}
  }
  try {
    const whichRes = execSync('which xray 2>/dev/null', { timeout: 1000 }).toString().trim();
    if (whichRes && fs.existsSync(whichRes)) {
      cachedXrayPath = whichRes;
      return whichRes;
    }
  } catch (e) {}

  cachedXrayPath = null;
  return null;
}

// Helper: Dynamically find an available TCP port on localhost for test instance
function getAvailableTestPort() {
  return new Promise((resolve, reject) => {
    const srv = net.createServer();
    srv.listen(0, '127.0.0.1', () => {
      const p = srv.address().port;
      srv.close(() => resolve(p));
    });
    srv.on('error', reject);
  });
}

// Concurrency limiter for isolated Xray proxy tests (max 2 concurrent processes on router)
let activeProxyChecks = 0;
const proxyCheckQueue = [];

function runWithProxyConcurrency(fn) {
  return new Promise((resolve, reject) => {
    const execute = async () => {
      activeProxyChecks++;
      try {
        const res = await fn();
        resolve(res);
      } catch (err) {
        reject(err);
      } finally {
        activeProxyChecks--;
        if (proxyCheckQueue.length > 0) {
          const next = proxyCheckQueue.shift();
          next();
        }
      }
    };

    if (activeProxyChecks < 2) {
      execute();
    } else {
      proxyCheckQueue.push(execute);
    }
  });
}

// Helper: Real proxy tunnel check via isolated ephemeral Xray instance
async function measureProxyHealth(outboundContent, options = {}) {
  const xrayBin = findXrayPath();
  if (!xrayBin) {
    return { ok: false, error: 'Исполняемый файл Xray не найден', skipProxy: true };
  }

  if (!outboundContent || typeof outboundContent !== 'string') {
    return { ok: false, error: 'Отсутствует конфигурация outbound', skipProxy: true };
  }

  let parsed;
  try {
    parsed = parseJsonWithComments(outboundContent);
  } catch (e) {
    return { ok: false, error: 'Некорректный синтаксис JSON outbound', skipProxy: true };
  }

  const outbounds = Array.isArray(parsed.outbounds) ? parsed.outbounds : [parsed];
  if (!outbounds || outbounds.length === 0) {
    return { ok: false, error: 'В конфигурации нет секции outbounds', skipProxy: true };
  }

  return runWithProxyConcurrency(async () => {
    const timeout = options.timeout || 4000;
    const canaryUrl = options.canaryUrl || 'http://cp.cloudflare.com/generate_204';

    let testPort;
    try {
      testPort = await getAvailableTestPort();
    } catch (err) {
      return { ok: false, error: 'Не удалось выделить порт: ' + err.message };
    }

    const testConfigFile = path.join(
      os.tmpdir(),
      `xray-health-${Date.now()}-${Math.floor(Math.random() * 100000)}.json`
    );

    const testConfig = {
      log: { loglevel: 'none' },
      inbounds: [
        {
          tag: 'test-http-in',
          port: testPort,
          listen: '127.0.0.1',
          protocol: 'http'
        }
      ],
      outbounds: outbounds
    };

    try {
      fs.writeFileSync(testConfigFile, JSON.stringify(testConfig));
    } catch (err) {
      return { ok: false, error: 'Ошибка записи тестового конфига: ' + err.message };
    }

    let child;
    try {
      child = spawn(xrayBin, ['run', '-c', testConfigFile], {
        stdio: ['ignore', 'ignore', 'ignore']
      });
    } catch (err) {
      try { fs.unlinkSync(testConfigFile); } catch (e) {}
      return { ok: false, error: 'Ошибка запуска Xray: ' + err.message };
    }

    const cleanup = () => {
      try { child.kill('SIGKILL'); } catch (e) {}
      try { fs.unlinkSync(testConfigFile); } catch (e) {}
    };

    return new Promise((resolve) => {
      let settled = false;

      const finish = (res) => {
        if (!settled) {
          settled = true;
          cleanup();
          resolve(res);
        }
      };

      child.on('error', (err) => {
        finish({ ok: false, error: 'Сбой процесса Xray: ' + err.message });
      });

      child.on('exit', (code) => {
        if (!settled && code !== 0 && code !== null) {
          finish({ ok: false, error: `Xray завершился с кодом ошибки ${code}` });
        }
      });

      // Short delay (250ms) to allow Xray to bind local HTTP inbound port
      setTimeout(() => {
        if (settled) return;

        let canaryParsed;
        try {
          canaryParsed = new URL(canaryUrl);
        } catch (e) {
          return finish({ ok: false, error: 'Некорректный Canary URL' });
        }

        const t0 = Date.now();
        const req = http.request(
          {
            host: '127.0.0.1',
            port: testPort,
            method: 'GET',
            path: canaryUrl,
            headers: { Host: canaryParsed.host },
            timeout: timeout
          },
          (res) => {
            const latency = Date.now() - t0;
            res.resume();
            if (res.statusCode >= 200 && res.statusCode < 400) {
              finish({ ok: true, latency, statusCode: res.statusCode });
            } else {
              finish({
                ok: false,
                latency: null,
                statusCode: res.statusCode,
                error: `Прокси вернул HTTP ${res.statusCode} (трафик сброшен сервером)`
              });
            }
          }
        );

        req.on('timeout', () => {
          req.destroy();
          finish({ ok: false, error: 'Таймаут сквозного ответа через туннель' });
        });

        req.on('error', (err) => {
          finish({ ok: false, error: 'Сбой соединения через прокси: ' + (err.message || 'ошибка сети') });
        });

        req.end();
      }, 250);
    });
  });
}

// Helper: Comprehensive connection health check (TCP handshake + real proxy tunnel test)
async function measureConnectionHealth(conn, options = {}) {
  if (!conn) {
    return { ok: false, error: 'Подключение не указано', status: 'unreachable', latency: null };
  }

  const timeout = options.timeout || 3500;

  // Step 1: TCP handshake to destination host:port
  const isUdpProxy = conn.protocol === 'hysteria' || conn.network === 'hysteria';
  const tcpRes = isUdpProxy ? { ok: true, latency: null }
    : await measureTcpLatency(conn.serverAddress, conn.serverPort, Math.min(timeout, 3000));
  if (!tcpRes.ok) {
    return {
      ok: false,
      latency: null,
      tcpLatency: null,
      status: 'unreachable',
      checkType: 'tcp_failed',
      error: tcpRes.error || 'Порт сервера недоступен'
    };
  }

  // Step 2: Real proxy check (if Xray is installed on router and outbound JSON is present)
  const xrayBin = findXrayPath();
  if (xrayBin && conn.outboundContent) {
    const proxyRes = await measureProxyHealth(conn.outboundContent, {
      timeout: timeout,
      canaryUrl: options.canaryUrl
    });

    if (proxyRes.ok) {
      return {
        ok: true,
        latency: proxyRes.latency,
        tcpLatency: tcpRes.latency,
        status: 'ok',
        checkType: 'proxy',
        statusCode: proxyRes.statusCode
      };
    } else if (proxyRes.skipProxy && !isUdpProxy) {
      // If outbound could not be tested due to config formatting, fall back to TCP
      return {
        ok: true,
        latency: tcpRes.latency,
        tcpLatency: tcpRes.latency,
        status: 'ok',
        checkType: 'tcp',
        warning: proxyRes.error
      };
    } else {
      // Proxy failed: host TCP was alive, but tunnel rejected or dropped traffic!
      return {
        ok: false,
        latency: null,
        tcpLatency: tcpRes.latency,
        status: 'unreachable',
        checkType: 'proxy_failed',
        error: proxyRes.error || 'Прокси не пропускает трафик'
      };
    }
  }

  // Fallback to TCP ping if Xray binary is not installed in environment
  if (isUdpProxy) return { ok: false, latency: null, status: 'unreachable', checkType: 'proxy_unavailable', error: 'Для проверки Hysteria2 нужен Xray с поддержкой этого протокола.' };
  return {
    ok: true,
    latency: tcpRes.latency,
    tcpLatency: tcpRes.latency,
    status: 'ok',
    checkType: 'tcp'
  };
}

// Helper: Sleep
function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

// Helper: Resolve GeoIP (Country Code & Name) via free ip-api.com
function resolveGeoIp(host) {
  return new Promise((resolve) => {
    if (!host || typeof host !== 'string') return resolve(null);
    const cleanHost = host.trim().replace(/^\[|\]$/g, '');
    if (!cleanHost) return resolve(null);

    // Skip local / private addresses
    if (cleanHost === 'localhost' || cleanHost === '127.0.0.1' || cleanHost.startsWith('192.168.') || cleanHost.startsWith('10.') || cleanHost.startsWith('172.16.')) {
      return resolve(null);
    }

    try {
      const url = `http://ip-api.com/json/${encodeURIComponent(cleanHost)}?fields=status,country,countryCode`;
      const req = http.get(url, { timeout: 4000 }, (res) => {
        let body = '';
        res.on('data', chunk => { body += chunk; });
        res.on('end', () => {
          try {
            if (res.statusCode >= 200 && res.statusCode < 300) {
              const parsed = JSON.parse(body);
              if (parsed && parsed.status === 'success' && parsed.countryCode) {
                return resolve({
                  countryCode: String(parsed.countryCode).toUpperCase(),
                  countryName: parsed.country || ''
                });
              }
            }
          } catch (e) {}
          resolve(null);
        });
      });

      req.on('timeout', () => {
        req.destroy();
        resolve(null);
      });

      req.on('error', () => {
        resolve(null);
      });
    } catch (e) {
      resolve(null);
    }
  });
}

let isGeoIpSweeping = false;
async function sweepGeoIpForConnections() {
  if (isGeoIpSweeping) return;
  isGeoIpSweeping = true;
  try {
    const data = loadData();
    let updated = false;
    for (const conn of data.connections) {
      if (!conn.countryCode && conn.serverAddress) {
        const geo = await resolveGeoIp(conn.serverAddress);
        if (geo) {
          conn.countryCode = geo.countryCode;
          conn.countryName = geo.countryName;
          updated = true;
          console.log(`[GeoIP] Determined country for "${conn.name}" (${conn.serverAddress}) -> ${geo.countryName} (${geo.countryCode})`);
        }
        await sleep(300);
      }
    }
    if (updated) {
      saveData(data);
    }
  } catch (err) {
    console.error('[GeoIP] Error sweeping connections:', err);
  } finally {
    isGeoIpSweeping = false;
  }
}

// Helper to execute shell command safely
function runShellCommand(cmd, timeout = 15000) {
  return new Promise((resolve) => {
    if (!cmd || !cmd.trim()) {
      return resolve({ success: true, stdout: '', stderr: '', code: 0, error: null });
    }
    exec(cmd.trim(), { timeout }, (error, stdout, stderr) => {
      const outStr = stdout ? stdout.toString().trim() : '';
      const errStr = stderr ? stderr.toString().trim() : (error ? error.message : '');
      const code = error && error.code !== undefined ? error.code : (error ? 1 : 0);
      resolve({
        success: !error,
        code,
        stdout: outStr,
        stderr: errStr,
        error: error ? (error.message || errStr) : null
      });
    });
  });
}

// Helper to download a file with HTTP/HTTPS redirects support
function downloadFileWithRedirects(fileUrl, destPath, maxRedirects = 6) {
  return new Promise((resolve, reject) => {
    if (maxRedirects < 0) {
      return reject(new Error('Слишком много перенаправлений при скачивании файла'));
    }
    let parsedUrl;
    try {
      parsedUrl = new URL(fileUrl);
    } catch (e) {
      return reject(new Error('Некорректный URL: ' + fileUrl));
    }
    const client = parsedUrl.protocol === 'https:' ? https : http;
    const options = {
      headers: {
        'User-Agent': 'xKeenVlessSwitcher-Updater',
        'Accept': '*/*'
      },
      timeout: 30000
    };
    const req = client.get(fileUrl, options, (res) => {
      if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location) {
        let redirectUrl = res.headers.location;
        if (!redirectUrl.startsWith('http')) {
          redirectUrl = new URL(redirectUrl, fileUrl).href;
        }
        res.resume();
        return downloadFileWithRedirects(redirectUrl, destPath, maxRedirects - 1)
          .then(resolve)
          .catch(reject);
      }
      if (res.statusCode !== 200) {
        res.resume();
        return reject(new Error(`Ошибка скачивания: HTTP ${res.statusCode} ${res.statusMessage || ''}`));
      }
      const fileStream = fs.createWriteStream(destPath);
      res.pipe(fileStream);
      fileStream.on('finish', () => {
        fileStream.close(() => resolve());
      });
      fileStream.on('error', (err) => {
        try { fs.unlinkSync(destPath); } catch (e) {}
        reject(err);
      });
    });
    req.on('timeout', () => {
      req.destroy();
      reject(new Error('Таймаут соединения при скачивании файла обновления'));
    });
    req.on('error', (err) => {
      try { fs.unlinkSync(destPath); } catch (e) {}
      reject(err);
    });
  });
}

// Helper to recursively copy directories with exclusion list
function copyDirRecursiveSync(srcDir, destDir, excludeNames = []) {
  if (!fs.existsSync(destDir)) {
    fs.mkdirSync(destDir, { recursive: true });
  }
  const entries = fs.readdirSync(srcDir, { withFileTypes: true });
  for (const entry of entries) {
    if (excludeNames.includes(entry.name)) {
      continue;
    }
    const srcPath = path.join(srcDir, entry.name);
    const destPath = path.join(destDir, entry.name);

    if (entry.isDirectory()) {
      copyDirRecursiveSync(srcPath, destPath, excludeNames);
    } else if (entry.isSymbolicLink()) {
      try {
        const link = fs.readlinkSync(srcPath);
        if (fs.existsSync(destPath)) fs.unlinkSync(destPath);
        fs.symlinkSync(link, destPath);
      } catch (e) {}
    } else {
      fs.copyFileSync(srcPath, destPath);
    }
  }
}

// Evaluate service status from command output and exit code
function evaluateServiceStatus(res) {
  const combined = ((res.stdout || '') + ' ' + (res.stderr || '') + ' ' + (res.error || '')).toLowerCase();
  
  if (combined.includes('failed') || combined.includes('fatal') || combined.includes('panic') || combined.includes('syntax error') || combined.includes('invalid config') || combined.includes('cannot start') || combined.includes('ошибка')) {
    return 'error';
  }

  if (combined.includes('stopped') || combined.includes('not running') || combined.includes('is not running') || combined.includes('is dead') || combined.includes('inactive') || combined.includes('остановлен') || combined.includes('не запущен') || combined.includes('не работает')) {
    return 'stopped';
  }

  if (combined.includes('is running') || combined.includes(' running') || combined.includes('[ok] xray is running') || combined.includes('active (running)') || combined.includes('работает') || (combined.includes('запущен') && !combined.includes('не запущен') && !combined.includes('не работает'))) {
    return 'running';
  }

  if (res.success && res.code === 0) {
    return 'running';
  }

  return 'error';
}

// Write target file safely
function writeTargetFile(filePath, content) { atomicWrite(filePath,content); }

// --- PURE JS ZIP CREATOR & PARSER ---
function getDosDateTime(d = new Date()) {
  const year = Math.max(1980, d.getFullYear());
  const month = d.getMonth() + 1;
  const day = d.getDate();
  const hours = d.getHours();
  const minutes = d.getMinutes();
  const seconds = Math.floor(d.getSeconds() / 2);

  const dosDate = ((year - 1980) << 9) | (month << 5) | day;
  const dosTime = (hours << 11) | (minutes << 5) | seconds;
  return { dosDate, dosTime };
}

const CRC32_TABLE = new Int32Array(256);
for (let i = 0; i < 256; i++) {
  let c = i;
  for (let k = 0; k < 8; k++) c = ((c & 1) ? (0xEDB88320 ^ (c >>> 1)) : (c >>> 1));
  CRC32_TABLE[i] = c;
}

function calculateCrc32(buf) {
  let crc = -1;
  for (let i = 0; i < buf.length; i++) crc = (crc >>> 8) ^ CRC32_TABLE[(crc ^ buf[i]) & 0xFF];
  return (crc ^ (-1)) >>> 0;
}

function createZipBuffer(files) {
  const localHeaders = [];
  const centralHeaders = [];
  let currentOffset = 0;
  const { dosDate, dosTime } = getDosDateTime();

  files.forEach(file => {
    const filenameBuf = Buffer.from(file.filename, 'utf8');
    const dataBuf = Buffer.isBuffer(file.content) ? file.content : Buffer.from(file.content, 'utf8');
    const crc = calculateCrc32(dataBuf);
    const size = dataBuf.length;
    const isUtf8 = /[^\x00-\x7F]/.test(file.filename);
    const flag = isUtf8 ? 0x0800 : 0;
    const versionNeeded = 10;

    const lh = Buffer.alloc(30 + filenameBuf.length + size);
    lh.writeUInt32LE(0x04034b50, 0);
    lh.writeUInt16LE(versionNeeded, 4);
    lh.writeUInt16LE(flag, 6);
    lh.writeUInt16LE(0, 8);
    lh.writeUInt16LE(dosTime, 10);
    lh.writeUInt16LE(dosDate, 12);
    lh.writeUInt32LE(crc, 14);
    lh.writeUInt32LE(size, 18);
    lh.writeUInt32LE(size, 22);
    lh.writeUInt16LE(filenameBuf.length, 26);
    lh.writeUInt16LE(0, 28);
    filenameBuf.copy(lh, 30);
    dataBuf.copy(lh, 30 + filenameBuf.length);
    localHeaders.push(lh);

    const ch = Buffer.alloc(46 + filenameBuf.length);
    ch.writeUInt32LE(0x02014b50, 0);
    ch.writeUInt16LE(0x0014, 4);
    ch.writeUInt16LE(versionNeeded, 6);
    ch.writeUInt16LE(flag, 8);
    ch.writeUInt16LE(0, 10);
    ch.writeUInt16LE(dosTime, 12);
    ch.writeUInt16LE(dosDate, 14);
    ch.writeUInt32LE(crc, 16);
    ch.writeUInt32LE(size, 20);
    ch.writeUInt32LE(size, 24);
    ch.writeUInt16LE(filenameBuf.length, 28);
    ch.writeUInt16LE(0, 30);
    ch.writeUInt16LE(0, 32);
    ch.writeUInt16LE(0, 34);
    ch.writeUInt16LE(0, 36);
    ch.writeUInt32LE(0x00000020, 38);
    ch.writeUInt32LE(currentOffset, 42);
    filenameBuf.copy(ch, 46);
    centralHeaders.push(ch);

    currentOffset += lh.length;
  });

  const cdOffset = currentOffset;
  const cdBuffer = Buffer.concat(centralHeaders);
  const cdSize = cdBuffer.length;

  const eocd = Buffer.alloc(22);
  eocd.writeUInt32LE(0x06054b50, 0);
  eocd.writeUInt16LE(0, 4);
  eocd.writeUInt16LE(0, 6);
  eocd.writeUInt16LE(files.length, 8);
  eocd.writeUInt16LE(files.length, 10);
  eocd.writeUInt32LE(cdSize, 12);
  eocd.writeUInt32LE(cdOffset, 16);
  eocd.writeUInt16LE(0, 20);

  return Buffer.concat([...localHeaders, cdBuffer, eocd]);
}

function parseZipBuffer(buf) {
  const entries = [];
  let expandedSize = 0;
  if (buf.length > 12 * 1024 * 1024) throw Error('Архив превышает 12 МБ.');
  if (!Buffer.isBuffer(buf) || buf.length < 22) return entries;
  let eocdOffset = -1;
  for (let i = buf.length - 22; i >= 0; i--) {
    if (buf.readUInt32LE(i) === 0x06054b50) {
      eocdOffset = i;
      break;
    }
  }

  if (eocdOffset !== -1) {
    const cdEntries = buf.readUInt16LE(eocdOffset + 10);
    if (cdEntries > 6000) throw Error('Слишком много файлов в архиве.');
    let cdOffset = buf.readUInt32LE(eocdOffset + 16);
    let count = 0;
    while (cdOffset + 46 <= buf.length && count < cdEntries) {
      const sig = buf.readUInt32LE(cdOffset);
      if (sig !== 0x02014b50) break;

      const compMethod = buf.readUInt16LE(cdOffset + 10);
      const compSize = buf.readUInt32LE(cdOffset + 20);
      const unpackedSize = buf.readUInt32LE(cdOffset + 24);
      if(unpackedSize>16*1024*1024-expandedSize) throw Error('Распакованный архив превышает 16 МБ.');
      const fnameLen = buf.readUInt16LE(cdOffset + 28);
      const extraLen = buf.readUInt16LE(cdOffset + 30);
      const commentLen = buf.readUInt16LE(cdOffset + 32);
      const localHeaderOffset = buf.readUInt32LE(cdOffset + 42);

      if (cdOffset + 46 + fnameLen > buf.length) break;

      const filename = buf.toString('utf8', cdOffset + 46, cdOffset + 46 + fnameLen);
      cdOffset += 46 + fnameLen + extraLen + commentLen;
      count++;

      if (filename.endsWith('/')) continue;

      if (localHeaderOffset + 30 <= buf.length) {
        const localSig = buf.readUInt32LE(localHeaderOffset);
        if (localSig === 0x04034b50) {
          const localFnameLen = buf.readUInt16LE(localHeaderOffset + 26);
          const localExtraLen = buf.readUInt16LE(localHeaderOffset + 28);
          const dataStart = localHeaderOffset + 30 + localFnameLen + localExtraLen;
          const dataEnd = dataStart + compSize;

          if (dataEnd <= buf.length) {
            const rawData = buf.slice(dataStart, dataEnd);
            let strContent = '';
            if (compMethod === 0) {
              strContent = rawData.toString('utf8');
            } else if (compMethod === 8) {
              try {
                strContent = zlib.inflateRawSync(rawData, {maxOutputLength:16*1024*1024-expandedSize}).toString('utf8');
              } catch (e) {
                try {
                  strContent = zlib.inflateSync(rawData, {maxOutputLength:16*1024*1024-expandedSize}).toString('utf8');
                } catch (e2) { throw Error('Архив повреждён или превышает лимит распаковки.'); }
              }
            }
            expandedSize += Buffer.byteLength(strContent);
            if (expandedSize > 16*1024*1024) throw Error('Распакованный архив превышает 16 МБ.');
            if(![0,8].includes(compMethod)) throw Error('Метод сжатия ZIP не поддерживается.');
            entries.push({ filename, content: strContent });
          }
        }
      }
    }
  }
  return entries;
}

// Load data from file with v1.0 migration and auto-detection
function loadDataRaw() {
  const detected = detectConfigPaths();
  let data = {
    settings: {
      outboundPath: detected.outboundPath,
      routingPath: detected.routingPath,
      restartCommand: 'xkeen -restart',
      startCommand: 'xkeen -start',
      stopCommand: 'xkeen -stop',
      statusCommand: 'xkeen -status',
      activeConnectionId: null,
      port: 3000,
      failover: {
        enabled: false,
        primaryConnectionId: '',
        backupConnectionId: '',
        checkIntervalSec: 25,
        failThreshold: 3,
        recoveryThreshold: 3,
        ruCheckHost: '77.88.8.8',
        ruCheckPort: 53,
        canaryUrl: 'http://cp.cloudflare.com/generate_204',
        state: 'normal',
        lastCheckAt: null,
        lastSwitchAt: null,
        consecutiveFails: 0,
        consecutiveSuccesses: 0,
        lastLog: 'Авто-переключение не настроено'
      },
      autoFailover: {
        enabled: false,
        strategy: 'lowest_ping',
        primaryMode: 'manual_active',
        preferredPrimaryId: '',
        specificPrimaryId: '',
        poolConnectionIds: [],
        checkIntervalSec: 20,
        failThreshold: 3,
        autoReturn: true,
        recoveryThreshold: 3,
        canaryUrl: 'http://cp.cloudflare.com/generate_204',
        state: 'normal',
        activeBackupId: null,
        lastCheckAt: null,
        lastSwitchAt: null,
        consecutiveFails: 0,
        consecutiveSuccesses: 0,
        lastLog: 'Авто-резерв не настроен'
      }
    },
    connections: [],
    subscriptions: [],
    routings: [
      { ...SYSTEM_ROUTING_ALL_VPN },
      { ...SYSTEM_ROUTING_EXCEPT_RU }
    ]
  };

  try {
    if (fs.existsSync(DATA_FILE)) {
      const content = fs.readFileSync(DATA_FILE, 'utf8');
      const parsed = JSON.parse(content);
      if (!parsed || typeof parsed!=='object' || Array.isArray(parsed) || !parsed.settings || (!Array.isArray(parsed.connections) && !Array.isArray(parsed.profiles))) throw Error('Invalid database');
      validateIds(parsed);
      data.subscriptions = Array.isArray(parsed.subscriptions) ? parsed.subscriptions : [];

      data.settings = {
        ...data.settings,
        ...(parsed.settings || {}),
        failover: {
          ...data.settings.failover,
          ...((parsed.settings && parsed.settings.failover) || {})
        },
        autoFailover: {
          ...data.settings.autoFailover,
          ...((parsed.settings && parsed.settings.autoFailover) || {})
        }
      };

      if (!data.settings.activeConnectionId && parsed.settings && parsed.settings.activeProfileId) {
        data.settings.activeConnectionId = parsed.settings.activeProfileId;
      }

      if (data.settings.outboundPath && !fs.existsSync(data.settings.outboundPath) && fs.existsSync(detected.outboundPath)) {
        data.settings.outboundPath = detected.outboundPath;
      }
      if (data.settings.routingPath && !fs.existsSync(data.settings.routingPath) && fs.existsSync(detected.routingPath)) {
        data.settings.routingPath = detected.routingPath;
      }

      // Load Routings
      if (Array.isArray(parsed.routings) && parsed.routings.length > 0) {
        data.routings = parsed.routings;
      }

      // Ensure system routing 1 "Всё через VPN" exists and is properly locked
      const sysRoutingIdx = data.routings.findIndex(r => r.id === 'routing_all_vpn' || r.name === 'Всё через VPN');
      let sysAllVpn;
      if (sysRoutingIdx === -1) {
        sysAllVpn = { ...SYSTEM_ROUTING_ALL_VPN };
      } else {
        data.routings[sysRoutingIdx].isSystem = true;
        data.routings[sysRoutingIdx].name = 'Всё через VPN';
        data.routings[sysRoutingIdx].id = 'routing_all_vpn';
        data.routings[sysRoutingIdx].content = SYSTEM_ROUTING_ALL_VPN.content;
        sysAllVpn = data.routings[sysRoutingIdx];
      }

      // Ensure system routing 2 "Всё через VPN кроме РФ" exists and is properly locked
      const sysExceptRuIdx = data.routings.findIndex(r => r.id === 'routing_except_ru' || (!r.replacesSystemRouting && (r.name === 'Всё через VPN кроме РФ' || r.name === 'Все кроме РФ через VPN')));
      let sysExceptRu;
      if (sysExceptRuIdx === -1) {
        sysExceptRu = { ...SYSTEM_ROUTING_EXCEPT_RU };
      } else {
        const oldId = data.routings[sysExceptRuIdx].id;
        data.routings[sysExceptRuIdx].isSystem = true;
        data.routings[sysExceptRuIdx].name = 'Всё через VPN кроме РФ';
        data.routings[sysExceptRuIdx].id = 'routing_except_ru';
        data.routings[sysExceptRuIdx].description = SYSTEM_ROUTING_EXCEPT_RU.description;
        data.routings[sysExceptRuIdx].content = SYSTEM_ROUTING_EXCEPT_RU.content;
        sysExceptRu = data.routings[sysExceptRuIdx];

        if (oldId && oldId !== 'routing_except_ru' && Array.isArray(parsed.connections)) {
          for (const conn of parsed.connections) {
            if (conn.routingId === oldId) {
              conn.routingId = 'routing_except_ru';
            }
          }
        }
      }

      // Order routings: User configs first, Protected/System configs under them
      const userRoutings = data.routings.filter(r => !r.isSystem && r.id !== 'routing_all_vpn' && r.id !== 'routing_except_ru');
      data.routings = [...userRoutings, sysAllVpn, sysExceptRu];

      // Load Connections
      if (Array.isArray(parsed.connections) && parsed.connections.length > 0) {
        data.connections = parsed.connections.map(c => {
          const meta = extractOutboundMetadata(c.outboundContent);
          return {
            ...c,
            id: c.id,
            name: connectionName(c) || 'Подключение',
            description: c.description || '',
            routingId: c.routingId || 'routing_all_vpn',
            outboundContent: c.outboundContent || '',
            serverAddress: c.serverAddress || meta.serverAddress || '',
            serverPort: c.serverPort || meta.serverPort || null,
            protocol: c.protocol || meta.protocol || 'vless',
            network: c.network || meta.network || 'tcp',
            security: c.security || meta.security || 'none',
            sni: c.sni || meta.sni || '',
            countryCode: c.countryCode || null,
            countryName: c.countryName || null,
            lastPing: c.lastPing !== undefined ? c.lastPing : null,
            lastPingStatus: c.lastPingStatus || null,
            lastPingError: c.lastPingError || null,
            lastPingType: c.lastPingType || null,
            lastPingCheckedAt: c.lastPingCheckedAt || null,
            createdAt: c.createdAt || new Date().toISOString()
          };
        });
      }

      // Auto-recover connection if connections array is empty but outbound file exists
      if (data.connections.length === 0 && data.settings.outboundPath && fs.existsSync(data.settings.outboundPath)) {
        try {
          const content = fs.readFileSync(data.settings.outboundPath, 'utf8');
          if (content.trim()) {
            const meta = extractOutboundMetadata(content);
            if (meta.serverAddress) {
              const customRouting = data.routings.find(r => !r.isSystem);
              const connId = 'conn_aeza_swe';
              const autoConn = {
                id: connId,
                name: 'AEZA SWE',
                description: 'Автоматически импортировано из активной конфигурации Xray',
                routingId: customRouting ? customRouting.id : 'routing_all_vpn',
                outboundContent: content,
                serverAddress: meta.serverAddress,
                serverPort: meta.serverPort,
                protocol: meta.protocol || 'vless',
                network: meta.network || 'tcp',
                security: meta.security || 'reality',
                sni: meta.sni || '',
                createdAt: new Date().toISOString()
              };
              data.connections.push(autoConn);
              data.settings.activeConnectionId = connId;
            }
          }
        } catch (autoErr) {
          console.error('Error auto-importing outbound config:', autoErr);
        }
      }

      return applyRoutingReplacements(data);
    }
  } catch (err) {
    throw new Error('База настроек повреждена или недоступна. Восстановите проверенную резервную копию; исходный файл сохранён.');
  }

  return applyRoutingReplacements(data);
}

// Save data to file
function loadData() {
  const data = healthStore.overlay(loadDataRaw());
  dataSnapshots.set(data, structuredClone(data));
  return data;
}

function saveData(data) {
  try {
    validateIds(data);
    const base = dataSnapshots.get(data);
    const next = base ? mergeChanges(base, data, healthStore.overlay(loadDataRaw())) : data;
    validateIds(next);
    if(fs.existsSync(DATA_FILE)) {loadDataRaw();atomicWrite(DATA_FILE+'.last-good',fs.readFileSync(DATA_FILE));}
    const persistent=structuredClone(next);
    for(const conn of persistent.connections) for(const key of ['lastPing','lastPingStatus','lastPingError','lastPingType','lastPingCheckedAt']) delete conn[key];
    atomicWrite(DATA_FILE, JSON.stringify(persistent));
    for(const conn of next.connections) healthStore.set(conn);
    healthStore.prune(next.connections);
    // Track this request's own state; unrelated concurrent additions remain in the file.
    dataSnapshots.set(data, structuredClone(data));
    return true;
  } catch (err) {
    throw new Error('Не удалось сохранить настройки. Проверьте свободное место и права доступа.');
  }
}

// Internal: Activate connection files and execute restart command
async function validateTargetFiles(files) {
  for (const file of files) parseJsonWithComments(file.content);
  const binary = findXrayPath();
  if (!binary) return; // Developer/test environments do not have Xray.
  await require('./lib/xray-validation').validateXrayFiles(files, binary);
}
async function restartChecked(command,statusCommand,timings={}) {
  if (!command?.trim()) return;
  const started = performance.now();
  const result = await runShellCommand(command.trim());
  timings.restartCommandMs = Math.round(performance.now() - started);
  if (result.code !== 0 || result.error) throw Error('Служба не перезапустилась.');
  if(statusCommand?.trim()) {
    const statusStarted = performance.now();
    const status = evaluateServiceStatus(await runShellCommand(statusCommand.trim()));
    timings.statusMs = Math.round(performance.now() - statusStarted);
    if(status !== 'running') throw Error('Служба не подтвердила запуск.');
  }
}
async function activateConnectionInternal(connId, data, updateActiveState = true, extraGuard = () => {}) {
  const started = performance.now();
  const timings = {};
  const generation = automationGeneration;
  const baseline = dataSnapshots.get(data) || loadData();
  const expectedActive = baseline.settings.activeConnectionId;
  const expectedConn = baseline.connections.find(c=>c.id===connId);
  const conn = data.connections.find(c=>c.id===connId);
  if (!conn) throw Error('Подключение не найдено');
  const routing = data.routings.find(r=>r.id===conn.routingId) || SYSTEM_ROUTING_ALL_VPN;
  return applyQueue(async()=>{
    timings.queueMs = Math.round(performance.now() - started);
    const guard = () => {
      extraGuard();
      const latest=loadData(), candidate=latest.connections.find(c=>c.id===connId);
      if (isUpdatingApp || generation!==automationGeneration || latest.settings.activeConnectionId!==expectedActive || candidate?.outboundContent!==expectedConn?.outboundContent || candidate?.routingId!==expectedConn?.routingId || JSON.stringify(latest.routings)!==JSON.stringify(baseline.routings)) throw Error('Настройки изменились. Операция отменена.');
    };
    await applyFiles({timings,files:[{path:data.settings.outboundPath,content:conn.outboundContent},{path:data.settings.routingPath,content:routing.content}],guard,validate:validateTargetFiles,restart:()=>restartChecked(data.settings.restartCommand,data.settings.statusCommand,timings),persist:()=>{
      if(updateActiveState) {data.settings.activeConnectionId=connId;delete conn.requiresActivation;saveData(data);}
    }});
    lastServiceStatus={status:'running',output:'Конфигурация применена',error:'',code:0,timestamp:new Date().toISOString()};
    timings.totalMs = Math.round(performance.now() - started);
    return {conn,routing,timings,fileWriteStatus:{outbound:true,routing:true,error:null},restartStatus:{executed:!!data.settings.restartCommand,output:'',error:''},serviceStatus:lastServiceStatus};
  });
}

// ==============================================================================
// FAILOVER WATCHDOG ENGINE (БЕЛЫЕ СПИСКИ / RECOVERY)
// ==============================================================================
let failoverTimer = null;
let failoverRunning = false;
let failoverCooldownUntil = 0;
let lastFailoverCheckTime = 0;

function checkCanary(urlStr = 'http://cp.cloudflare.com/generate_204', timeout = 3500) {
  return new Promise((resolve) => {
    try {
      const u = new URL(urlStr);
      const client = u.protocol === 'https:' ? https : http;
      const req = client.get(u, { timeout }, (res) => {
        res.resume();
        if (res.statusCode >= 200 && res.statusCode < 400) {
          resolve({ ok: true, statusCode: res.statusCode });
        } else {
          resolve({ ok: false, error: `HTTP ${res.statusCode}` });
        }
      });
      req.on('timeout', () => {
        req.destroy();
        resolve({ ok: false, error: 'Таймаут соединения' });
      });
      req.on('error', (err) => {
        resolve({ ok: false, error: err.message || 'Ошибка сети' });
      });
    } catch (e) {
      resolve({ ok: false, error: e.message || 'Ошибка URL' });
    }
  });
}

function loadFailoverHistory() {
  try {
    if (fs.existsSync(FAILOVER_LOG_FILE)) {
      const content = fs.readFileSync(FAILOVER_LOG_FILE, 'utf8');
      const parsed = JSON.parse(content);
      if (Array.isArray(parsed)) return parsed;
    }
  } catch (e) {
    console.error('[Failover] Error reading history:', e.message);
  }
  return [];
}

function appendFailoverHistory(entry) {
  try {
    const list = loadFailoverHistory();
    const newRecord = {
      id: 'fo_' + Date.now() + '_' + Math.random().toString(36).substr(2, 4),
      timestamp: new Date().toISOString(),
      ...entry
    };
    list.unshift(newRecord);
    const trimmed = list.slice(0, 100);
    fs.writeFileSync(FAILOVER_LOG_FILE, JSON.stringify(trimmed, null, 2), 'utf8');
    return newRecord;
  } catch (e) {
    console.error('[Failover] Error saving history:', e.message);
  }
}

function clearFailoverHistory() {
  try {
    fs.writeFileSync(FAILOVER_LOG_FILE, JSON.stringify([], null, 2), 'utf8');
    return true;
  } catch (e) {
    console.error('[Failover] Error clearing history:', e.message);
    return false;
  }
}

function startFailoverWatchdog() {
  if (failoverTimer) clearInterval(failoverTimer);
  failoverTimer = setInterval(failoverTick, 5000);
  console.log('[Failover] Фоновый монитор БС запущен');
}

async function failoverTick() {
  if (failoverRunning || isUpdatingApp) return;

  const cycleGeneration=automationGeneration;
  const guard=()=>{if(cycleGeneration!==automationGeneration || !loadData().settings.failover?.enabled) throw Error('Настройки изменились, проверка отменена.');};
  const data = loadData();
  const fo = data.settings && data.settings.failover;
  if (!fo || !fo.enabled) return;
  if (!fo.primaryConnectionId || !fo.backupConnectionId) {
    fo.enabled = false;
    fo.lastLog = 'Режим БС отключен: не заданы основное или резервное подключения';
    saveData(data);
    return;
  }

  const primaryConn = data.connections.find(c => c.id === fo.primaryConnectionId);
  const backupConn = data.connections.find(c => c.id === fo.backupConnectionId);

  if (!primaryConn || !backupConn) {
    fo.enabled = false;
    fo.lastLog = 'Режим БС отключен: выбранные подключения не найдены в списке';
    saveData(data);
    return;
  }

  const now = Date.now();
  if (now < failoverCooldownUntil) {
    return;
  }

  const intervalMs = Math.max(10, (fo.checkIntervalSec || 25)) * 1000;
  if (now - lastFailoverCheckTime < intervalMs) {
    return;
  }

  lastFailoverCheckTime = now;
  failoverRunning = true;

  try {
    const currentActiveId = data.settings.activeConnectionId;

    // Step 1: Check Russian internet link liveness
    const ruHost = (fo.ruCheckHost || '77.88.8.8').trim();
    const ruPort = parseInt(fo.ruCheckPort, 10) || 53;
    const ruPing = await measureTcpLatency(ruHost, ruPort, 2000);
      guard();

    fo.lastCheckAt = new Date().toISOString();

    if (!ruPing.ok) {
      fo.state = 'suspended';
      fo.lastLog = `Провайдер недоступен (Рунет ${ruHost}:${ruPort} не отвечает). Переключения заблокированы.`;
      saveData(data);
      return;
    }

    // Step 2: State-based checks
    const isCurrentlyOnBackup = (currentActiveId === fo.backupConnectionId);

    if (!isCurrentlyOnBackup) {
      // Normal state (Primary active): check if Primary VLESS / foreign internet works
      const primPing = await measureConnectionHealth(primaryConn, { timeout: 3500, canaryUrl: fo.canaryUrl });
      guard();
      let healthy = primPing.ok;

      // If TCP socket opened but proxy check was skipped, also test Canary URL
      if (healthy && fo.canaryUrl && primPing.checkType !== 'proxy') {
        const canaryRes = await checkCanary(fo.canaryUrl, 3500);
      guard();
        healthy = canaryRes.ok;
      }

      if (!healthy) {
        fo.consecutiveFails = (fo.consecutiveFails || 0) + 1;
        fo.consecutiveSuccesses = 0;
        fo.lastLog = `Основной VLESS не отвечает (${fo.consecutiveFails}/${fo.failThreshold || 3})`;

        if (fo.consecutiveFails >= (fo.failThreshold || 3)) {
          console.log(`[Failover] Activating backup connection: ${backupConn.name}`);
          fo.state = 'backup';
          fo.consecutiveFails = 0;
          fo.lastSwitchAt = new Date().toISOString();
          fo.lastLog = `Блокировка БС! Переключено на "${backupConn.name}"`;

          await activateConnectionInternal(fo.primaryConnectionId, data, true, guard);
          guard();
          appendFailoverHistory({
            event: 'switch_to_backup',
            title: 'Переключение на БС (Резерв)',
            fromName: primaryConn.name,
            toName: backupConn.name,
            reason: `Зафиксировано сбоев проверок подряд: ${fo.failThreshold || 3}. Домашний интернет в РФ доступен.`
          });

          failoverCooldownUntil = Date.now() + 60000;
        }
      } else {
        fo.state = 'normal';
        fo.consecutiveFails = 0;
        fo.lastLog = `Основное подключение стабильно (${primPing.latency} ms)`;
      }
    } else {
      // Backup state: probe if Primary connection is unblocked
      const primPing = await measureConnectionHealth(primaryConn, { timeout: 3500, canaryUrl: fo.canaryUrl });
      guard();

      if (primPing.ok) {
        fo.consecutiveSuccesses = (fo.consecutiveSuccesses || 0) + 1;
        fo.lastLog = `Основной сервер отвечает (${fo.consecutiveSuccesses}/${fo.recoveryThreshold || 3}, пинг ${primPing.latency} ms)`;

        if (fo.consecutiveSuccesses >= (fo.recoveryThreshold || 3)) {
          console.log(`[Failover] Primary unblocked! Switching back to: ${primaryConn.name}`);
          fo.state = 'normal';
          fo.consecutiveSuccesses = 0;
          fo.lastSwitchAt = new Date().toISOString();
          fo.lastLog = `БС отключены! Возврат на основной профиль "${primaryConn.name}"`;

          appendFailoverHistory({
            event: 'switch_to_primary',
            title: 'Возврат на основной VLESS',
            fromName: backupConn.name,
            toName: primaryConn.name,
            reason: `Основной сервер ответил успешно ${fo.recoveryThreshold || 3} раз(а) подряд (блокировка зарубежных серверов снята).`
          });

          failoverCooldownUntil = Date.now() + 60000;
        }
      } else {
        fo.consecutiveSuccesses = 0;
        fo.state = 'backup';
        fo.lastLog = `Режим БС активен. Основной VLESS пока недоступен`;
      }
    }

    guard();
    saveData(data);
  } catch (err) {
    console.error('[Failover] Error in watchdog tick:', err);
  } finally {
    failoverRunning = false;
  }
}

// ==============================================================================
// AUTO-FAILOVER WATCHDOG ENGINE (ОБЩЕЕ РЕЗЕРВИРОВАНИЕ ПОДКЛЮЧЕНИЙ)
// ==============================================================================
let autoFailoverTimer = null;
let autoFailoverRunning = false;
let autoFailoverCooldownUntil = 0;
let lastAutoFailoverCheckTime = 0;

function loadAutoFailoverHistory() {
  try {
    if (fs.existsSync(AUTOFAILOVER_LOG_FILE)) {
      const content = fs.readFileSync(AUTOFAILOVER_LOG_FILE, 'utf8');
      const parsed = JSON.parse(content);
      if (Array.isArray(parsed)) return parsed;
    }
  } catch (e) {
    console.error('[AutoFailover] Error reading history:', e.message);
  }
  return [];
}

function appendAutoFailoverHistory(entry) {
  try {
    const list = loadAutoFailoverHistory();
    const newRecord = {
      id: 'af_' + Date.now() + '_' + Math.random().toString(36).substr(2, 4),
      timestamp: new Date().toISOString(),
      ...entry
    };
    list.unshift(newRecord);
    const trimmed = list.slice(0, 100);
    fs.writeFileSync(AUTOFAILOVER_LOG_FILE, JSON.stringify(trimmed, null, 2), 'utf8');
    return newRecord;
  } catch (e) {
    console.error('[AutoFailover] Error saving history:', e.message);
  }
}

function clearAutoFailoverHistory() {
  try {
    fs.writeFileSync(AUTOFAILOVER_LOG_FILE, JSON.stringify([], null, 2), 'utf8');
    return true;
  } catch (e) {
    console.error('[AutoFailover] Error clearing history:', e.message);
    return false;
  }
}

function startAutoFailoverWatchdog() {
  if (autoFailoverTimer) clearInterval(autoFailoverTimer);
  autoFailoverTimer = setInterval(autoFailoverTick, 5000);
  console.log('[AutoFailover] Фоновый монитор авто-резерва запущен');
}

let autoReserve;
async function autoFailoverTick() {
  if(isUpdatingApp) return;
  if (!autoReserve) autoReserve=require('./lib/auto-reserve').createAutoReserve({loadData,saveData,health:measureConnectionHealth,activate:activateConnectionInternal,history:appendAutoFailoverHistory,generation:()=>automationGeneration});
  try {await autoReserve.tick();} catch { /* A stale cycle must never overwrite newer settings. */ }
}

// MIME types for static server
const MIME_TYPES = {
  '.html': 'text/html; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.js': 'application/javascript; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.png': 'image/png',
  '.ico': 'image/x-icon',
  '.woff2': 'font/woff2',
  '.woff': 'font/woff',
  '.ttf': 'font/ttf',
  '.otf': 'font/otf'
};
const serveStatic=require('./lib/static-files').createStaticHandler(PUBLIC_DIR,appVersion,MIME_TYPES);

// Helper: send JSON response
function sendJson(res, statusCode, data) {
  res.writeHead(statusCode, {
    'Content-Type': 'application/json; charset=utf-8',
    'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type, X-HTTP-Method-Override'
  });
  res.end(JSON.stringify(data));
}

// Helper: parse request body JSON
function parseJsonBody(req) {
  return new Promise((resolve, reject) => {
    let body = '';
    const decoder=new (require('node:string_decoder').StringDecoder)('utf8');
    let size = 0, exceeded = false;
    req.on('data', chunk => {
      size += chunk.length;
      if (size > 16 * 1024 * 1024) { exceeded = true; body = ''; return; }
      if (!exceeded) body += decoder.write(chunk);
    });
    req.on('aborted', () => reject(Error('Запрос прерван.')));
    req.on('error', reject);
    req.on('end', () => {
      try {
        if (exceeded) throw Error('Запрос превышает допустимый размер 16 МБ.');
        body+=decoder.end();
        resolve(body ? JSON.parse(body) : {});
      } catch (err) {
        reject(err);
      }
    });
  });
}

// Initialize data and port
let initialData;
try { initialData = loadData(); } catch { initialData = {settings:{port:3000}}; }
const PORT = process.env.PORT || (initialData.settings && initialData.settings.port) || 3000;
const subscriptions = createSubscriptionManager({ loadData, saveData, parseVlessUrl });

const routingSync = createRoutingSync({ loadData, saveData, parseJson: parseJsonWithComments, apply: async (id) => {
  const current=loadData();const active=current.connections.find(c=>c.id===current.settings.activeConnectionId);
  if(active?.routingId===id) await activateConnectionInternal(active.id,current,true);
} });

// Create HTTP Server
async function handleRequest(req, res) {
  const urlParts = req.url.split('?')[0];


  if (urlParts.startsWith('/api/')) {
    if(isUpdatingApp && ['POST','PUT','DELETE'].includes(req.method)) return sendJson(res,409,{error:'Обновление приложения выполняется. Изменения временно заблокированы.'});
    res.setHeader('Cache-Control','no-store');
    if(Number(req.headers['content-length'])>16*1024*1024) return sendJson(res,413,{error:'Размер запроса превышает лимит 16 МиБ.'});
    if (!trustedOrigin(req)) return sendJson(res,403,{error:'Недопустимый источник запроса.'});
    if (req.method==='OPTIONS') {res.writeHead(204);return res.end();}

  }
  if (['POST','PUT','DELETE'].includes(req.method) && (/^\/api\/(settings|autofailover\/(settings|toggle)|failover\/(settings|toggle)|backup\/restore|connections|subscriptions|service|routings|routing-sync)/.test(urlParts) || /\/(activate|set-routing)$/.test(urlParts))) automationGeneration++;
  // --- API ROUTES ---

  // GET /api/data
  if (urlParts === '/api/data' && req.method === 'GET') {
    const data = loadData();
    if(new URL(req.url,'http://localhost').searchParams.get('compact')==='1') data.connections=data.connections.map(({outboundContent,...conn})=>({...conn,outboundRevision:require('./lib/health-store').fingerprint({outboundContent})}));
    return sendJson(res, 200, { ...data, routingSources, routingSourceLists, subscriptions: data.subscriptions.map(x => publicSubscription(x, data.connections)), version: appVersion, updateRepository });
  }
  if(req.method==='GET' && /^\/api\/connections\/[\w-]+$/.test(urlParts)) {
    const conn=loadData().connections.find(c=>c.id===urlParts.split('/').pop());
    return sendJson(res,conn?200:404,conn||{error:'Подключение не найдено'});
  }
  if(req.method==='GET' && urlParts==='/api/app/storage') {
    const storage=require('./lib/storage');
    return sendJson(res,200,{runtimeBytes:storage.bytes(PUBLIC_DIR)+storage.bytes(path.join(__dirname,'lib'))+storage.bytes(__filename)+storage.bytes(path.join(__dirname,'package.json')),dataBytes:storage.bytes(DATA_DIR),freeBytes:storage.available(DATA_DIR),memory:process.memoryUsage()});
  }

  // Check pinned source versions before downloading and replacing managed domains.
  if (urlParts === '/api/routing-sync/refresh' && req.method === 'POST') {
    try { return sendJson(res, 200, await routingSync.refresh()); }
    catch (e) { return sendJson(res, 400, { error: e.message }); }
  }

  // GET /api/version
  if (urlParts === '/api/version' && req.method === 'GET') {
    loadData();
    return sendJson(res, 200, { version: appVersion, updateRepository });
  }

  if (urlParts === '/api/subscriptions' || urlParts.startsWith('/api/subscriptions/')) {
    try {
      if (urlParts === '/api/subscriptions') {
        if (req.method === 'GET') return sendJson(res, 200, { subscriptions: subscriptions.list() });
        if (req.method === 'POST') return sendJson(res, 201, await subscriptions.add(await parseJsonBody(req)));
      }
      const match = urlParts.match(/^\/api\/subscriptions\/([^/]+)(?:\/(refresh|exclusions))?$/);
      if (match) {
        const [, id, action] = match;
        if (req.method === 'GET' && !action) {
          res.setHeader('Cache-Control', 'no-store');
          const sub = loadData().subscriptions.find(x => x.id === decodeURIComponent(id));
          if (!sub) return sendJson(res, 404, { error: 'Подписка не найдена' });
          return sendJson(res, 200, { url: sub.url });
        }
        if (req.method === 'POST' && action === 'refresh') return sendJson(res, 200, { stats: await subscriptions.refresh(id) });
        if (req.method === 'DELETE' && action === 'exclusions') { subscriptions.resetExclusions(id); return sendJson(res, 200, { message: 'Исключения сброшены. Обновите подписку для возврата серверов.' }); }
        if (req.method === 'PUT' && !action) { subscriptions.edit(id, await parseJsonBody(req)); return sendJson(res, 200, { message: 'Подписка сохранена' }); }
        if (req.method === 'DELETE' && !action) { subscriptions.remove(id); return sendJson(res, 200, { message: 'Подписка удалена, подключения сохранены' }); }
      }
      return sendJson(res, 404, { error: 'Действие не найдено' });
    } catch (err) { return sendJson(res, 400, { error: err.message }); }
  }

  if(urlParts==='/api/app/latest' && req.method==='GET') {
    try {const info=await require('./lib/updater').createUpdater({root:__dirname,dataDir:DATA_DIR,repository:updateRepository}).latest();const {files,...visible}=info;return sendJson(res,200,visible);}
    catch(error) {return sendJson(res,400,{error:error.message});}
  }
  if(urlParts==='/api/app/update' && req.method==='POST') {
    if(isUpdatingApp) return sendJson(res,409,{error:'Обновление уже выполняется.'});
    isUpdatingApp=true;
    automationGeneration++;
    try {
      const body=await parseJsonBody(req);
      if(!/^[a-f0-9]{40}$/.test(body.sha||'')) throw Error('Сначала проверьте версию обновления.');
      const initScript='/opt/etc/init.d/S99xkeen-switcher';
      if(!fs.existsSync(initScript) || !fs.existsSync('/opt/var/run/xkeen-switcher.pid') || fs.readFileSync('/opt/var/run/xkeen-switcher.pid','utf8').trim()!==String(process.pid)) throw Error('Автоустановка требует запуска текущего процесса штатной службой Entware.');
      const update=await require('./lib/updater').createUpdater({root:__dirname,dataDir:DATA_DIR,repository:updateRepository}).prepare(body.sha);
      await applyQueue(async()=>{
        const workerDir=path.join(update.stage,'worker');fs.mkdirSync(workerDir);
        for(const name of ['operations.js','storage.js','update-worker.js']) fs.copyFileSync(path.join(__dirname,'lib',name),path.join(workerDir,name));
        const job={...update,root:__dirname,dataDir:DATA_DIR,initScript,port:server.address().port};
        const jobPath=path.join(update.stage,'job.json');atomicWrite(jobPath,JSON.stringify(job));
        atomicWrite(path.join(DATA_DIR,'update-status.json'),JSON.stringify({state:'prepared',version:update.version,stage:update.stage}));
        const child=spawn(process.execPath,[path.join(workerDir,'update-worker.js'),jobPath],{detached:true,stdio:'ignore',windowsHide:true});
        await new Promise((resolve,reject)=>{child.once('spawn',resolve);child.once('error',reject);});child.unref();
      });
      return sendJson(res,202,{success:true,message:'Файлы проверены. Ожидается запуск и проверка новой версии.',version:update.version});
    } catch(error) {isUpdatingApp=false;return sendJson(res,400,{error:error.message});}
  }

  // GET /api/failover - Get current failover status and settings
  if (urlParts === '/api/failover' && req.method === 'GET') {
    const data = loadData();
    return sendJson(res, 200, {
      failover: data.settings.failover || {},
      activeConnectionId: data.settings.activeConnectionId
    });
  }

  // POST /api/failover/settings - Update failover settings
  if (urlParts === '/api/failover/settings' && req.method === 'POST') {
    try {
      const body = await parseJsonBody(req);
      const data = loadData();
      const enabled = Boolean(body.enabled);
      const primaryConnectionId = body.primaryConnectionId || '';
      const backupConnectionId = body.backupConnectionId || '';

      if (enabled) {
        if (!primaryConnectionId || !data.connections.some(c => c.id === primaryConnectionId)) {
          return sendJson(res, 400, { error: 'Не выбрано основное подключение!' });
        }
        if (!backupConnectionId || !data.connections.some(c => c.id === backupConnectionId)) {
          return sendJson(res, 400, { error: 'Не выбрано резервное подключение (для Белых Списков)!' });
        }
        if (primaryConnectionId === backupConnectionId) {
          return sendJson(res, 400, { error: 'Основное и резервное подключения должны отличаться!' });
        }
      }

      data.settings.failover = {
        ...(data.settings.failover || {}),
        enabled,
        primaryConnectionId,
        backupConnectionId,
        checkIntervalSec: Math.max(10, parseInt(body.checkIntervalSec, 10) || 25),
        failThreshold: Math.max(1, parseInt(body.failThreshold, 10) || 3),
        recoveryThreshold: Math.max(1, parseInt(body.recoveryThreshold, 10) || 3),
        ruCheckHost: (body.ruCheckHost || '77.88.8.8').trim(),
        ruCheckPort: parseInt(body.ruCheckPort, 10) || 53,
        canaryUrl: (body.canaryUrl || 'http://cp.cloudflare.com/generate_204').trim(),
        consecutiveFails: 0,
        consecutiveSuccesses: 0,
        lastLog: enabled ? 'Настройки обновлены. Авто-мониторинг активен.' : 'Авто-переключение отключено.'
      };

      saveData(data);
      failoverCooldownUntil = Date.now() + 15000; // 15s pause after saving settings

      return sendJson(res, 200, {
        message: 'Настройки авто-переключения сохранены',
        failover: data.settings.failover
      });
    } catch (err) {
      return sendJson(res, 400, { error: err.message || 'Ошибка сохранения настроек' });
    }
  }

  // POST /api/failover/toggle - Quick toggle enable/disable
  if (urlParts === '/api/failover/toggle' && req.method === 'POST') {
    try {
      const body = await parseJsonBody(req);
      const data = loadData();
      const enabled = Boolean(body.enabled);

      if (!data.settings.failover) {
        data.settings.failover = {};
      }

      if (enabled) {
        const fo = data.settings.failover;
        let primaryId = fo.primaryConnectionId;
        if (body.primaryConnectionId !== undefined) {
          primaryId = body.primaryConnectionId;
        } else if (!primaryId) {
          primaryId = data.settings.activeConnectionId;
        }

        let backupId = fo.backupConnectionId;
        if (body.backupConnectionId !== undefined) {
          backupId = body.backupConnectionId;
        }

        const primaryExists = data.connections.some(c => c.id === primaryId);
        const backupExists = data.connections.some(c => c.id === backupId);

        if (!primaryId || !primaryExists) {
          return sendJson(res, 400, {
            error: 'Не выбрано основное подключение! Выберите его перед включением БС.'
          });
        }
        if (!backupId || !backupExists) {
          return sendJson(res, 400, {
            error: 'Не выбрано резервное подключение для Белых Списков! Выберите его перед включением.'
          });
        }
        if (primaryId === backupId) {
          return sendJson(res, 400, {
            error: 'Основное и резервное подключения не должны совпадать!'
          });
        }

        data.settings.failover.primaryConnectionId = primaryId;
        data.settings.failover.backupConnectionId = backupId;
      }

      data.settings.failover.enabled = enabled;
      data.settings.failover.lastLog = enabled
        ? 'Мониторинг БС включен'
        : 'Мониторинг БС отключен';

      saveData(data);
      failoverCooldownUntil = Date.now() + 3000;

      return sendJson(res, 200, {
        message: enabled ? 'Режим БС включен' : 'Режим БС отключен',
        enabled,
        failover: data.settings.failover
      });
    } catch (err) {
      return sendJson(res, 400, { error: err.message || 'Ошибка переключения' });
    }
  }

  // GET /api/failover/history - Get failover switch history
  if (urlParts === '/api/failover/history' && req.method === 'GET') {
    const history = loadFailoverHistory();
    return sendJson(res, 200, { history });
  }

  // POST /api/failover/history/clear - Clear failover switch history
  if (urlParts === '/api/failover/history/clear' && req.method === 'POST') {
    const success = clearFailoverHistory();
    return sendJson(res, 200, { success, message: 'Журнал переключений очищен' });
  }

  // GET /api/autofailover - Get current auto-failover status and settings
  if (urlParts === '/api/autofailover' && req.method === 'GET') {
    const data = loadData();
    return sendJson(res, 200, {
      autoFailover: data.settings.autoFailover || {},
      activeConnectionId: data.settings.activeConnectionId
    });
  }

  // POST /api/autofailover/settings - Update auto-failover settings
  if (urlParts === '/api/autofailover/settings' && req.method === 'POST') {
    try {
      const body = await parseJsonBody(req);
      const data = loadData();

      if (body.enabled && (!Array.isArray(body.poolConnectionIds) || !body.poolConnectionIds.length)) return sendJson(res,400,{error:'Выберите резервные подключения.'});
      if (body.poolConnectionIds?.some(id=>!data.connections.some(c=>c.id===id))) return sendJson(res,400,{error:'Резервное подключение не найдено.'});
      automationGeneration++;
      data.settings.autoFailover = {
        ...(data.settings.autoFailover || {}),
        enabled: Boolean(body.enabled),
        strategy: body.strategy === 'priority_order' ? 'priority_order' : 'lowest_ping',
        primaryMode: body.primaryMode === 'specific_id' ? 'specific_id' : 'manual_active',
        specificPrimaryId: body.specificPrimaryId || '',
        preferredPrimaryId: body.preferredPrimaryId || data.settings.activeConnectionId || '',
        poolConnectionIds: Array.isArray(body.poolConnectionIds) ? body.poolConnectionIds : [],
        checkIntervalSec: Math.max(10, parseInt(body.checkIntervalSec, 10) || 20),
        failThreshold: Math.max(1, parseInt(body.failThreshold, 10) || 3),
        autoReturn: body.autoReturn !== undefined ? Boolean(body.autoReturn) : true,
        recoveryThreshold: Math.max(1, parseInt(body.recoveryThreshold, 10) || 3),
        canaryUrl: (body.canaryUrl || 'http://cp.cloudflare.com/generate_204').trim(),
        consecutiveFails: 0,
        consecutiveSuccesses: 0,
        lastLog: body.enabled ? 'Настройки обновлены. Авто-резерв активен.' : 'Авто-резерв отключен.'
      };

      saveData(data);
      autoFailoverCooldownUntil = Date.now() + 15000; // 15s pause after saving settings

      return sendJson(res, 200, {
        message: 'Настройки авто-резерва сохранены',
        autoFailover: data.settings.autoFailover
      });
    } catch (err) {
      return sendJson(res, 400, { error: err.message || 'Ошибка сохранения настроек' });
    }
  }

  // POST /api/autofailover/toggle - Quick toggle enable/disable
  if (urlParts === '/api/autofailover/toggle' && req.method === 'POST') {
    try {
      const body = await parseJsonBody(req);
      const data = loadData();
      const enabled = Boolean(body.enabled);

      if (!data.settings.autoFailover) {
        data.settings.autoFailover = {};
      }

      data.settings.autoFailover.enabled = enabled;
      data.settings.autoFailover.lastLog = enabled
        ? 'Авто-переключение включено'
        : 'Авто-переключение отключено';

      if (enabled && !data.settings.autoFailover.poolConnectionIds?.length) return sendJson(res,400,{error:'Выберите резервные подключения.'});
      automationGeneration++;

      saveData(data);
      autoFailoverCooldownUntil = Date.now() + 3000;

      return sendJson(res, 200, {
        message: enabled ? 'Авто-переключение включено' : 'Авто-переключение отключено',
        enabled,
        autoFailover: data.settings.autoFailover
      });
    } catch (err) {
      return sendJson(res, 400, { error: err.message || 'Ошибка переключения' });
    }
  }

  // GET /api/autofailover/history - Get auto-failover switch history
  if (urlParts === '/api/autofailover/history' && req.method === 'GET') {
    const history = loadAutoFailoverHistory();
    return sendJson(res, 200, { history });
  }

  // POST /api/autofailover/history/clear - Clear auto-failover switch history
  if (urlParts === '/api/autofailover/history/clear' && req.method === 'POST') {
    const success = clearAutoFailoverHistory();
    return sendJson(res, 200, { success, message: 'Журнал авто-резерва очищен' });
  }

  // POST /api/connections/parse-url - Parse VLESS link
  if (urlParts === '/api/connections/parse-url' && req.method === 'POST') {
    try {
      const body = await parseJsonBody(req);
      const { url } = body;
      if (!url) {
        return sendJson(res, 400, { error: 'Укажите ссылку подключения' });
      }
      const parsed = parseVlessUrl(url);
      return sendJson(res, 200, parsed);
    } catch (err) {
      return sendJson(res, 400, { error: err.message || 'Ошибка парсинга ссылки' });
    }
  }

  // GET /api/connections - List all connections
  if (urlParts === '/api/connections' && req.method === 'GET') {
    const data = loadData();
    return sendJson(res, 200, {
      connections: data.connections,
      activeConnectionId: data.settings.activeConnectionId
    });
  }

  // POST /api/connections - Add connection
  if (urlParts === '/api/connections' && req.method === 'POST') {
    try {
      const body = await parseJsonBody(req);
      let { name, description, routingId, outboundContent, url } = body;

      if (url && !outboundContent) {
        const parsedFromUrl = parseVlessUrl(url);
        name = name || parsedFromUrl.name;
        outboundContent = parsedFromUrl.outboundJson;
      }

      if (!name || !outboundContent) {
        return sendJson(res, 400, { error: 'Заполните название и содержимое outbound.json' });
      }

      try {
        parseJsonWithComments(outboundContent);
      } catch (e) {
        return sendJson(res, 400, { error: 'Синтаксическая ошибка в outbound.json: ' + e.message });
      }

      const data = loadData();

      if (!routingId || !data.routings.some(r => r.id === routingId)) {
        routingId = 'routing_all_vpn';
      }

      const meta = extractOutboundMetadata(outboundContent);
      let countryCode = null;
      let countryName = null;
      if (meta.serverAddress) {
        try {
          const geo = await resolveGeoIp(meta.serverAddress);
          if (geo) {
            countryCode = geo.countryCode;
            countryName = geo.countryName;
          }
        } catch (e) {}
      }

      const newConnection = {
        id: 'conn_' + Date.now() + '_' + Math.random().toString(36).substr(2, 4),
        name: name.trim(),
        description: (description || '').trim(),
        routingId: routingId,
        outboundContent: outboundContent.trim(),
        serverAddress: meta.serverAddress,
        serverPort: meta.serverPort,
        protocol: meta.protocol,
        network: meta.network,
        security: meta.security,
        sni: meta.sni,
        countryCode: countryCode,
        countryName: countryName,
        lastPing: null,
        lastPingStatus: null,
        lastPingCheckedAt: null,
        createdAt: new Date().toISOString()
      };

      data.connections.push(newConnection);
      saveData(data);

      return sendJson(res, 201, { message: 'Подключение успешно добавлено', connection: newConnection });
    } catch (err) {
      return sendJson(res, 400, { error: err.message || 'Некорректный запрос' });
    }
  }

  // PUT /api/connections/:id - Update connection
  if (urlParts.startsWith('/api/connections/') && !urlParts.includes('/activate') && !urlParts.includes('/ping') && !urlParts.includes('/set-routing') && (req.method === 'PUT' || (req.method === 'POST' && req.headers['x-http-method-override'] === 'PUT'))) {
    const id = urlParts.replace('/api/connections/', '');
    const data = loadData();
    const conn = data.connections.find(c => c.id === id);

    if (!conn) {
      return sendJson(res, 404, { error: 'Подключение не найдено' });
    }

    try {
      const body = await parseJsonBody(req);
      const { name, description, routingId, outboundContent } = body;

      if (!name || !outboundContent) {
        return sendJson(res, 400, { error: 'Заполните название и содержимое outbound.json' });
      }

      try {
        parseJsonWithComments(outboundContent);
      } catch (e) {
        return sendJson(res, 400, { error: 'Синтаксическая ошибка в outbound.json: ' + e.message });
      }

      conn.name = name.trim();
      conn.description = (description || '').trim();
      if (routingId && data.routings.some(r => r.id === routingId)) {
        conn.routingId = routingId;
      }
      conn.outboundContent = outboundContent.trim();
      
      const meta = extractOutboundMetadata(conn.outboundContent);
      const hostChanged = (conn.serverAddress !== meta.serverAddress);
      conn.serverAddress = meta.serverAddress;
      conn.serverPort = meta.serverPort;
      conn.protocol = meta.protocol;
      conn.network = meta.network;
      conn.security = meta.security;
      conn.sni = meta.sni;
      conn.updatedAt = new Date().toISOString();

      if (hostChanged || !conn.countryCode) {
        try {
          const geo = await resolveGeoIp(meta.serverAddress);
          if (geo) {
            conn.countryCode = geo.countryCode;
            conn.countryName = geo.countryName;
          }
        } catch (e) {}
      }

      let activationDetails = null;
      if (data.settings.activeConnectionId === id) {
        activationDetails = await activateConnectionInternal(id, data, true);
      } else {
        saveData(data);
      }

      return sendJson(res, 200, {
        message: 'Подключение успешно обновлено',
        connection: conn,
        activationDetails
      });
    } catch (err) {
      return sendJson(res, 400, { error: err.message || 'Некорректный запрос' });
    }
  }

  // POST /api/connections/:id/set-routing - Change routing (with ping check if active)
  if (urlParts.startsWith('/api/connections/') && urlParts.endsWith('/set-routing') && req.method === 'POST') {
    const id = urlParts.replace('/api/connections/', '').replace('/set-routing', '');
    const data = loadData();
    const conn = data.connections.find(c => c.id === id);

    if (!conn) {
      return sendJson(res, 404, { error: 'Подключение не найдено' });
    }

    try {
      const body = await parseJsonBody(req);
      const { routingId } = body;
      const targetRouting = data.routings.find(r => r.id === routingId);
      if (!targetRouting) {
        return sendJson(res, 400, { error: 'Выбранный роутинг не найден' });
      }

      conn.routingId = routingId;
      let msg = `Маршрутизация для "${conn.name}" изменена на "${targetRouting.name}"`;
      let pingResult = null;

      if (data.settings.activeConnectionId === id) await activateConnectionInternal(id,data,true);

      saveData(data);
      return sendJson(res, 200, {
        message: msg,
        connection: conn,
        routing: targetRouting,
        serviceStatus: lastServiceStatus,
        pingResult
      });
    } catch (err) {
      return sendJson(res, 400, { error: err.message || 'Ошибка обновления роутинга' });
    }
  }

  // DELETE /api/connections/:id - Delete connection
  if (urlParts.startsWith('/api/connections/') && !urlParts.includes('/activate') && !urlParts.includes('/ping') && req.method === 'DELETE') {
    const id = urlParts.replace('/api/connections/', '');
    const data = loadData();
    const index = data.connections.findIndex(c => c.id === id);

    if (index === -1) {
      return sendJson(res, 404, { error: 'Подключение не найдено' });
    }

    data.connections.splice(index, 1);
    if (data.settings.activeConnectionId === id) {
      data.settings.activeConnectionId = null;
    }

    // Clean up Failover (БС) references
    if (data.settings.failover) {
      if (data.settings.failover.primaryConnectionId === id) {
        data.settings.failover.primaryConnectionId = '';
        data.settings.failover.enabled = false;
        data.settings.failover.lastLog = 'Основное подключение удалено. Режим БС отключен.';
      }
      if (data.settings.failover.backupConnectionId === id) {
        data.settings.failover.backupConnectionId = '';
        data.settings.failover.enabled = false;
        data.settings.failover.lastLog = 'Резервное подключение удалено. Режим БС отключен.';
      }
    }

    // Clean up Auto-Failover references
    if (data.settings.autoFailover) {
      if (data.settings.autoFailover.specificPrimaryId === id) {
        data.settings.autoFailover.specificPrimaryId = '';
      }
      if (data.settings.autoFailover.preferredPrimaryId === id) {
        data.settings.autoFailover.preferredPrimaryId = '';
      }
      if (Array.isArray(data.settings.autoFailover.poolConnectionIds)) {
        data.settings.autoFailover.poolConnectionIds = data.settings.autoFailover.poolConnectionIds.filter(pid => pid !== id);
      }
    }

    saveData(data);
    return sendJson(res, 200, { message: 'Подключение удалено' });
  }

  // Return after validated restart; the UI requests a separate background health check.
  if (urlParts.startsWith('/api/connections/') && urlParts.endsWith('/activate') && req.method === 'POST') {
    const id = urlParts.replace('/api/connections/', '').replace('/activate', '');
    const data = loadData();

    try {
      const result = await activateConnectionInternal(id, data, true);

      // Update failover state if manual activation occurs
      if (data.settings.failover && data.settings.failover.enabled) {
        if (id === data.settings.failover.primaryConnectionId) {
          data.settings.failover.state = 'normal';
          data.settings.failover.consecutiveFails = 0;
          data.settings.failover.lastLog = `Вручную активирован основной профиль "${result.conn.name}"`;
        } else if (id === data.settings.failover.backupConnectionId) {
          data.settings.failover.state = 'backup';
          data.settings.failover.consecutiveSuccesses = 0;
          data.settings.failover.lastLog = `Вручную активирован резервный (БС) профиль "${result.conn.name}"`;
        } else {
          data.settings.failover.lastLog = `Вручную активирован сторонний профиль "${result.conn.name}"`;
        }
        failoverCooldownUntil = Date.now() + 60000; // 60s cooldown
      }

      // Update autoFailover state if manual activation occurs
      if (data.settings.autoFailover && data.settings.autoFailover.enabled) {
        const af = data.settings.autoFailover;
        if (af.primaryMode === 'manual_active') {
          af.preferredPrimaryId = id;
          af.state = 'normal';
          af.activeBackupId = null;
          af.consecutiveFails = 0;
          af.consecutiveSuccesses = 0;
          af.lastLog = `Вручную активирован профиль "${result.conn.name}". Установлен как основной.`;
        } else if (af.primaryMode === 'specific_id') {
          if (id === af.specificPrimaryId) {
            af.state = 'normal';
            af.activeBackupId = null;
            af.consecutiveFails = 0;
            af.consecutiveSuccesses = 0;
            af.lastLog = `Вручную активирован основной профиль "${result.conn.name}"`;
          } else {
            af.lastLog = `Вручную активирован профиль "${result.conn.name}"`;
          }
        }
        autoFailoverCooldownUntil = Date.now() + 60000; // 60s cooldown
      }

      saveData(data);

      return sendJson(res, 200, {
        message: `Подключение "${result.conn.name}" активировано!`,
        activeConnectionId: id,
        connectionName: result.conn.name,
        routingName: result.routing.name,
        fileWriteStatus: result.fileWriteStatus,
        restartStatus: result.restartStatus,
        serviceStatus: result.serviceStatus,
        timings: result.timings
      });
    } catch (err) {
      return sendJson(res, 400, { error: err.message || 'Ошибка активации подключения' });
    }
  }

  // POST /api/connections/:id/ping - Check single connection availability (TCP handshake + real proxy tunnel)
  if (urlParts.startsWith('/api/connections/') && urlParts.endsWith('/ping') && req.method === 'POST') {
    const id = urlParts.replace('/api/connections/', '').replace('/ping', '');
    const data = loadData();
    const conn = data.connections.find(c => c.id === id);

    if (!conn) {
      return sendJson(res, 404, { error: 'Подключение не найдено' });
    }

    try {
      const pingResult = await measureConnectionHealth(conn, { timeout: 3500 });

      conn.lastPing = pingResult.ok ? pingResult.latency : null;
      conn.lastPingStatus = pingResult.ok ? 'ok' : 'unreachable';
      conn.lastPingError = pingResult.error || null;
      conn.lastPingType = pingResult.checkType || 'tcp';
      conn.lastPingCheckedAt = new Date().toISOString();

      if (!conn.countryCode && conn.serverAddress) {
        try {
          const geo = await resolveGeoIp(conn.serverAddress);
          if (geo) {
            conn.countryCode = geo.countryCode;
            conn.countryName = geo.countryName;
          }
        } catch (e) {}
      }

      healthStore.set(conn);

      return sendJson(res, 200, {
        id: conn.id,
        ok: pingResult.ok,
        ping: conn.lastPing,
        status: conn.lastPingStatus,
        checkType: conn.lastPingType,
        error: conn.lastPingError,
        latencyStr: pingResult.ok ? `${conn.lastPing} ms` : 'Недоступен',
        checkedAt: conn.lastPingCheckedAt,
        countryCode: conn.countryCode,
        countryName: conn.countryName
      });
    } catch (err) {
      return sendJson(res, 500, { error: 'Ошибка проверки доступности: ' + err.message });
    }
  }

  // POST /api/connections/ping-all - Check all connections with concurrency limiter without touching service
  if (urlParts === '/api/connections/ping-all' && req.method === 'POST') {
    const data = loadData();
    if (!data.connections || data.connections.length === 0) {
      return sendJson(res, 200, { results: [], message: 'Нет подключений для проверки' });
    }

    try {
      const results = [];
      for (const conn of data.connections) {
        const pingResult = await measureConnectionHealth(conn, { timeout: 3500 });
        conn.lastPing = pingResult.ok ? pingResult.latency : null;
        conn.lastPingStatus = pingResult.ok ? 'ok' : 'unreachable';
        conn.lastPingError = pingResult.error || null;
        conn.lastPingType = pingResult.checkType || 'tcp';
        conn.lastPingCheckedAt = new Date().toISOString();

        if (!conn.countryCode && conn.serverAddress) {
          try {
            const geo = await resolveGeoIp(conn.serverAddress);
            if (geo) {
              conn.countryCode = geo.countryCode;
              conn.countryName = geo.countryName;
            }
          } catch (e) {}
        }

        results.push({
          id: conn.id,
          ok: pingResult.ok,
          ping: conn.lastPing,
          status: conn.lastPingStatus,
          checkType: conn.lastPingType,
          error: conn.lastPingError,
          latencyStr: pingResult.ok ? `${conn.lastPing} ms` : 'Недоступен',
          checkedAt: conn.lastPingCheckedAt,
          countryCode: conn.countryCode,
          countryName: conn.countryName
        });
      }

      for(const conn of data.connections) healthStore.set(conn);

      return sendJson(res, 200, {
        results,
        activeConnectionId: data.settings.activeConnectionId,
        message: `Проверено подключений: ${results.length}.`
      });
    } catch (err) {
      return sendJson(res, 500, { error: 'Ошибка при массовой проверке доступности: ' + err.message });
    }
  }

  // POST /api/connections/resolve-geoip - Background sweep GeoIP
  if (urlParts === '/api/connections/resolve-geoip' && req.method === 'POST') {
    sweepGeoIpForConnections();
    return sendJson(res, 200, { message: 'Фоновое определение стран запущено' });
  }

  // --- ROUTING CONFIGURATION ROUTES ---

  // GET /api/routings
  if (urlParts === '/api/routings' && req.method === 'GET') {
    const data = loadData();
    return sendJson(res, 200, { routings: data.routings });
  }

  // POST /api/routings
  if (urlParts === '/api/routings' && req.method === 'POST') {
    try {
      const body = await parseJsonBody(req);
      const { name, description, content } = body;

      if (!name || !content) {
        return sendJson(res, 400, { error: 'Заполните название и содержимое routing.json' });
      }

      try {
        parseJsonWithComments(content);
      } catch (e) {
        return sendJson(res, 400, { error: 'Синтаксическая ошибка в routing.json: ' + e.message });
      }

      const data = loadData();
      const newRouting = {
        id: 'routing_' + Date.now() + '_' + Math.random().toString(36).substr(2, 4),
        name: name.trim(),
        description: (description || '').trim(),
        isSystem: false,
        content: content.trim(),
        createdAt: new Date().toISOString()
      };

      const firstSysIdx = data.routings.findIndex(r => r.isSystem);
      if (firstSysIdx !== -1) {
        data.routings.splice(firstSysIdx, 0, newRouting);
      } else {
        data.routings.push(newRouting);
      }
      saveData(data);

      return sendJson(res, 201, { message: 'Конфигурация маршрутизации создана', routing: newRouting });
    } catch (err) {
      return sendJson(res, 400, { error: err.message || 'Некорректный запрос' });
    }
  }

  // PUT /api/routings/:id (forbidden for isSystem)
  if (urlParts.startsWith('/api/routings/') && (req.method === 'PUT' || (req.method === 'POST' && req.headers['x-http-method-override'] === 'PUT'))) {
    const id = urlParts.replace('/api/routings/', '');
    const data = loadData();
    const routing = data.routings.find(r => r.id === id);

    if (!routing) {
      return sendJson(res, 404, { error: 'Конфигурация маршрутизации не найдена' });
    }

    if (routing.isSystem) {
      return sendJson(res, 403, { error: `Системный роутинг "${routing.name}" защищен от редактирования` });
    }

    try {
      const body = await parseJsonBody(req);
      const { name, description, content } = body;

      if (!name || !content) {
        return sendJson(res, 400, { error: 'Заполните название и содержимое routing.json' });
      }

      try {
        parseJsonWithComments(content);
      } catch (e) {
        return sendJson(res, 400, { error: 'Синтаксическая ошибка в routing.json: ' + e.message });
      }

      routing.name = name.trim();
      routing.description = (description || '').trim();
      routing.content = content.trim();
      routing.updatedAt = new Date().toISOString();

      const activeConn = data.connections.find(c => c.id === data.settings.activeConnectionId);
      if (activeConn && activeConn.routingId === id) await activateConnectionInternal(activeConn.id,data,true);

      saveData(data);
      return sendJson(res, 200, { message: 'Конфигурация маршрутизации сохранена', routing });
    } catch (err) {
      return sendJson(res, 400, { error: err.message || 'Некорректный запрос' });
    }
  }

  // DELETE /api/routings/:id (forbidden for isSystem)
  if (urlParts.startsWith('/api/routings/') && req.method === 'DELETE') {
    const id = urlParts.replace('/api/routings/', '');
    const data = loadData();
    const index = data.routings.findIndex(r => r.id === id);

    if (index === -1) {
      return sendJson(res, 404, { error: 'Конфигурация маршрутизации не найдена' });
    }

    const routing = data.routings[index];
    if (routing.isSystem || routing.replacesSystemRouting === 'routing_except_ru') {
      return sendJson(res, 403, { error: `Системный роутинг "${routing.name}" защищен от удаления` });
    }

    for (const conn of data.connections) {
      if (conn.routingId === id) {
        conn.routingId = 'routing_all_vpn';
      }
    }

    data.routings.splice(index, 1);
    for (const sub of data.subscriptions) if (sub.routingId === id) sub.routingId = 'routing_all_vpn';
    saveData(data);
    return sendJson(res, 200, { message: 'Конфигурация маршрутизации удалена' });
  }

  // --- BACKUP & RESTORE ROUTES ---

  // GET /api/backup/export - Download full ZIP backup of settings, connections, and routings
  if (urlParts === '/api/backup/export' && req.method === 'GET') {
    const data = loadData();
    const nowStr = new Date().toISOString().replace(/[:.]/g, '-').slice(0, 19);

    const backupPayload = {
      app: 'xKeenVlessSwitcher',
      version: appVersion,
      exportedAt: new Date().toISOString(),
      settings: data.settings,
      connections: data.connections,
      subscriptions: data.subscriptions,
      routings: data.routings
    };

    const files = [
      { filename: 'backup.json', content: JSON.stringify(backupPayload, null, 2) },
      {
        filename: 'README.txt',
        content: `xKeenVlessSwitcher 2.0 Резервная копия\nСоздана: ${new Date().toLocaleString()}\nПодключений: ${data.connections.length}\nРоутингов: ${data.routings.length}\nВерсия: ${appVersion}\n`
      }
    ];

    // Also include individual config files for easy inspection
    data.connections.forEach((c, idx) => {
      const safeName = (c.name || 'conn').replace(/[^a-zA-Z0-9_\-\u0400-\u04FF]/g, '_');
      files.push({
        filename: `connections/${idx + 1}_${safeName}.json`,
        content: c.outboundContent
      });
    });

    data.routings.forEach((r, idx) => {
      const safeName = (r.name || 'routing').replace(/[^a-zA-Z0-9_\-\u0400-\u04FF]/g, '_');
      files.push({
        filename: `routings/${idx + 1}_${safeName}.json`,
        content: r.content
      });
    });

    const zipBuffer = createZipBuffer(files);
    const downloadName = `xkeen-backup-${nowStr}.zip`;

    res.writeHead(200, {
      'Content-Type': 'application/zip',
      'Content-Disposition': `attachment; filename="${downloadName}"`,
      'Content-Length': zipBuffer.length
    });
    return res.end(zipBuffer);
  }

  // POST /api/backup/restore - Restore settings, connections, and routings from uploaded ZIP or JSON
  if (urlParts === '/api/backup/restore' && req.method === 'POST') {
    try {
      const body = await parseJsonBody(req);
      let restoreData = null;

      if (body.zipBase64) {
        const zipBuf = Buffer.from(body.zipBase64, 'base64');
        const entries = parseZipBuffer(zipBuf);

        // Find backup.json
        const backupEntry = entries.find(e => /^backup\.json$/i.test(path.basename(e.filename)));
        if (backupEntry && backupEntry.content) {
          try { restoreData = JSON.parse(backupEntry.content); } catch (e) {}
        }

        if (!restoreData) {
          // Look for profiles.json or any json with connections/routings/profiles
          for (const ent of entries) {
            try {
              const parsed = JSON.parse(ent.content);
              if (parsed.connections || parsed.profiles || parsed.routings) {
                restoreData = parsed;
                break;
              }
            } catch (e) {}
          }
        }

        if (!restoreData) {
          // Assemble from connections/ and routings/ entries in ZIP
          const assembledConns = [];
          const assembledRoutings = [];
          for (const ent of entries) {
            if (/\bconnections\/.*\.json$/i.test(ent.filename) && ent.content) {
              const name = path.basename(ent.filename, path.extname(ent.filename)).replace(/^\d+_/, '').replace(/_/g, ' ');
              assembledConns.push({ name: name, outboundContent: ent.content });
            } else if (/\broutings\/.*\.json$/i.test(ent.filename) && ent.content) {
              const name = path.basename(ent.filename, path.extname(ent.filename)).replace(/^\d+_/, '').replace(/_/g, ' ');
              assembledRoutings.push({ name: name, content: ent.content });
            }
          }
          if (assembledConns.length > 0 || assembledRoutings.length > 0) {
            restoreData = { connections: assembledConns, routings: assembledRoutings };
          }
        }
      } else if (body.backupData) {
        restoreData = body.backupData;
      } else if (body.connections || body.profiles || body.routings) {
        restoreData = body;
      } else if (Array.isArray(body)) {
        restoreData = { connections: body };
      }

      if (!restoreData) {
        return sendJson(res, 400, { error: 'Не удалось извлечь данные резервной копии из файла. Убедитесь, что загружаемый файл является ZIP-архивом резервной копии или JSON-файлом.' });
      }

      validateIds(restoreData);
      const currentData = loadData();
      let restoredConnections = [];
      let restoredRoutings = [];

      // Restore Routings
      if (Array.isArray(restoreData.routings)) {
        restoredRoutings = restoreData.routings.map(r => ({
          id: r.id || ('routing_' + Date.now() + '_' + Math.random().toString(36).substr(2, 4)),
          name: r.name || 'Маршрутизация',
          description: r.description || '',
          isSystem: Boolean(r.isSystem || r.id === 'routing_all_vpn' || r.id === 'routing_except_ru' || (!r.replacesSystemRouting && (r.name === 'Всё через VPN' || r.name === 'Всё через VPN кроме РФ' || r.name === 'Все кроме РФ через VPN'))),
          content: r.content || '',
          domainSync: r.domainSync && typeof r.domainSync === 'object' ? r.domainSync : undefined,
          replacesSystemRouting: r.replacesSystemRouting === 'routing_except_ru' ? r.replacesSystemRouting : undefined,
          createdAt: r.createdAt || new Date().toISOString()
        }));
      }

      // Always guarantee system routing 1 exists
      const sysIdx = restoredRoutings.findIndex(r => r.id === 'routing_all_vpn' || r.name === 'Всё через VPN');
      if (sysIdx === -1) {
        restoredRoutings.unshift({ ...SYSTEM_ROUTING_ALL_VPN });
      } else {
        restoredRoutings[sysIdx] = { ...SYSTEM_ROUTING_ALL_VPN };
      }

      // Always guarantee system routing 2 exists
      const sysExceptRuIdx = restoredRoutings.findIndex(r => r.id === 'routing_except_ru' || (!r.replacesSystemRouting && (r.name === 'Всё через VPN кроме РФ' || r.name === 'Все кроме РФ через VPN')));
      if (sysExceptRuIdx === -1) {
        restoredRoutings.splice(1, 0, { ...SYSTEM_ROUTING_EXCEPT_RU });
      } else {
        restoredRoutings[sysExceptRuIdx] = { ...SYSTEM_ROUTING_EXCEPT_RU };
      }

      // Restore Connections (or migrate from profiles)
      const rawConnList = Array.isArray(restoreData.connections) ? restoreData.connections
        : (Array.isArray(restoreData.profiles) ? restoreData.profiles : []);

      restoredConnections = rawConnList.map(c => {
        const meta = extractOutboundMetadata(c.outboundContent || '');
        let targetRoutingId = c.routingId || 'routing_all_vpn';
        if (!restoredRoutings.some(r => r.id === targetRoutingId)) {
          targetRoutingId = 'routing_all_vpn';
        }
        return {
          subscriptionId: c.subscriptionId,
          subscriptionKey: c.subscriptionKey,
          subscriptionIdentity: c.subscriptionIdentity,
          subscriptionName: c.subscriptionName,
          subscriptionMissing: c.subscriptionMissing,
          id: c.id || ('conn_' + Date.now() + '_' + Math.random().toString(36).substr(2, 4)),
          name: c.name || 'Подключение',
          description: c.description || '',
          routingId: targetRoutingId,
          outboundContent: c.outboundContent || '',
          serverAddress: c.serverAddress || meta.serverAddress || '',
          serverPort: c.serverPort || meta.serverPort || null,
          protocol: c.protocol || meta.protocol || 'vless',
          network: c.network || meta.network || 'tcp',
          security: c.security || meta.security || 'none',
          sni: c.sni || meta.sni || '',
          lastPing: null,
          lastPingStatus: null,
          lastPingCheckedAt: null,
          createdAt: c.createdAt || new Date().toISOString()
        };
      });

      // Restore Settings
      const newSettings = {
        ...currentData.settings,
        ...(restoreData.settings || {})
      };

      // Validate activeConnectionId
      if (newSettings.activeConnectionId && !restoredConnections.some(c => c.id === newSettings.activeConnectionId)) {
        newSettings.activeConnectionId = restoredConnections.length > 0 ? restoredConnections[0].id : null;
      }

      const mergedData = {
        settings: newSettings,
        connections: restoredConnections,
        subscriptions: Array.isArray(restoreData.subscriptions) ? restoreData.subscriptions.map(s => ({
          ...s, url: subscriptionUrl(s.url).href, updatedAt: require('crypto').randomUUID(),
          routingId: restoredRoutings.some(r => r.id === s.routingId) ? s.routingId : 'routing_all_vpn'
        })) : [],
        routings: restoredRoutings
      };

      if (mergedData.settings.activeConnectionId) await activateConnectionInternal(mergedData.settings.activeConnectionId, mergedData, true);
      else saveData(mergedData);

      return sendJson(res, 200, {
        success: true,
        message: `Резервная копия успешно восстановлена: ${restoredConnections.length} подключений, ${restoredRoutings.length} роутингов`,
        counts: {
          connections: restoredConnections.length,
          routings: restoredRoutings.length
        }
      });
    } catch (err) {
      console.error('Error restoring backup:', err);
      return sendJson(res, 400, { error: 'Ошибка восстановления резервной копии: ' + err.message });
    }
  }

  // --- SERVICE CONTROL ROUTES ---

  // GET /api/service/status
  if (['/api/service/status','/api/status'].includes(urlParts) && req.method === 'GET') {
    const data = loadData();
    const cmd = data.settings.statusCommand || 'xkeen -status';
    const result = await runShellCommand(cmd);
    const computedStatus = evaluateServiceStatus(result);

    lastServiceStatus = {
      status: computedStatus,
      output: result.stdout || '',
      error: result.stderr || result.error || '',
      code: result.code,
      timestamp: new Date().toISOString(),
      command: cmd
    };
    return sendJson(res, 200, urlParts==='/api/status'?{service:lastServiceStatus,failover:data.settings.failover,autoFailover:data.settings.autoFailover}:lastServiceStatus);
  }

  // POST /api/service/restart
  if (urlParts === '/api/service/restart' && req.method === 'POST') {
    const data = loadData();
    const cmd = data.settings.restartCommand || 'xkeen -restart';
    const result = await applyQueue(()=>runShellCommand(cmd));
    const computedStatus = evaluateServiceStatus(result);

    lastServiceStatus = {
      status: computedStatus,
      output: result.stdout || '',
      error: result.stderr || result.error || '',
      code: result.code,
      timestamp: new Date().toISOString(),
      command: cmd
    };

    const isOk = computedStatus === 'running' || (result.success && !result.error);
    return sendJson(res, isOk ? 200 : 500, {
      message: isOk ? 'Служба XKeen успешно перезапущена' : 'Ошибка при перезапуске службы XKeen',
      ...lastServiceStatus
    });
  }

  // POST /api/service/start
  if (urlParts === '/api/service/start' && req.method === 'POST') {
    const data = loadData();
    const cmd = data.settings.startCommand || 'xkeen -start';
    const result = await applyQueue(()=>runShellCommand(cmd));
    const computedStatus = evaluateServiceStatus(result);

    lastServiceStatus = {
      status: computedStatus,
      output: result.stdout || '',
      error: result.stderr || result.error || '',
      code: result.code,
      timestamp: new Date().toISOString(),
      command: cmd
    };

    const isOk = computedStatus === 'running' || (result.success && !result.error);
    return sendJson(res, isOk ? 200 : 500, {
      message: isOk ? 'Служба XKeen успешно запущена' : 'Ошибка при запуске службы XKeen',
      ...lastServiceStatus
    });
  }

  // POST /api/service/stop
  if (urlParts === '/api/service/stop' && req.method === 'POST') {
    const data = loadData();
    const cmd = data.settings.stopCommand || 'xkeen -stop';
    const result = await applyQueue(()=>runShellCommand(cmd));
    const computedStatus = evaluateServiceStatus(result);

    lastServiceStatus = {
      status: computedStatus === 'running' ? 'stopped' : computedStatus,
      output: result.stdout || '',
      error: result.stderr || result.error || '',
      code: result.code,
      timestamp: new Date().toISOString(),
      command: cmd
    };

    return sendJson(res, result.success && !result.error ? 200 : 500, {
      message: result.success && !result.error ? 'Команда остановки службы XKeen выполнена' : 'Ошибка остановки службы XKeen',
      ...lastServiceStatus
    });
  }

  // GET /api/settings - Get current settings
  if (urlParts === '/api/settings' && req.method === 'GET') {
    const data = loadData();
    return sendJson(res, 200, { settings: data.settings });
  }

  // POST /api/settings - Update settings
  if (urlParts === '/api/settings' && req.method === 'POST') {
    try {
      const body = await parseJsonBody(req);
      const { outboundPath, routingPath, restartCommand, startCommand, stopCommand, statusCommand, port } = body;
      const data = loadData();

      let portChanged = false;
      let oldPort = server.address()?.port || data.settings.port || 3000;

      if (port !== undefined && port !== null && port !== '') {
        const p = Number(port);
        if (Number.isInteger(p) && p > 0 && p <= 65535) {
          if (oldPort !== p) {
            await require('./lib/listener').checkPort(p,HOST);
            portChanged = true;
          }
          data.settings.port = p;
        } else {
          return sendJson(res, 400, { error: 'Некорректный номер порта (от 1 до 65535)' });
        }
      }

      if (outboundPath) data.settings.outboundPath = outboundPath.trim();
      if (routingPath) data.settings.routingPath = routingPath.trim();
      if (restartCommand !== undefined) data.settings.restartCommand = restartCommand.trim();
      if (startCommand !== undefined) data.settings.startCommand = startCommand.trim();
      if (stopCommand !== undefined) data.settings.stopCommand = stopCommand.trim();
      if (statusCommand !== undefined) data.settings.statusCommand = statusCommand.trim();

      saveData(data);

      let message = 'Настройки сохранены';
      if (portChanged) {
        message = `Настройки сохранены! Порт панели изменен с ${oldPort} на ${data.settings.port}. Перезапуск сервера...`;
      }

      sendJson(res, 200, { message, settings: data.settings, portChanged, newPort: data.settings.port });

      if (portChanged) {
        setTimeout(()=>require('./lib/listener').rebind(server,data.settings.port,HOST,oldPort,async()=>{
          const latest=loadData();latest.settings.port=oldPort;saveData(latest);
        }).catch(()=>console.error('Не удалось изменить порт; проверьте адрес панели.')),150);
      }
      return;
    } catch (err) {
      return sendJson(res, 400, { error: 'Некорректные данные' });
    }
  }

  // --- STATIC FILE SERVER ---
  res.setHeader('X-Content-Type-Options','nosniff');
  res.setHeader('Referrer-Policy','no-referrer');
  res.setHeader('X-Frame-Options','DENY');
  return serveStatic(req,res);
}
const server = http.createServer((req,res) => { handleRequest(req,res).catch(() => { if (!res.headersSent) sendJson(res,500,{error:'Операция не выполнена. Проверьте базу настроек и журнал службы.'}); else res.end(); }); });

server.requestTimeout=30000;
server.headersTimeout=10000;
const HOST = process.env.HOST || '0.0.0.0';

if (require.main === module) server.listen(PORT, HOST, () => {
  console.log(`===================================================`);
  console.log(`🚀 xKeenVlessSwitcher ${appVersion} запущен на http://${HOST}:${PORT}`);
  console.log(`===================================================`);
  if (!process.env.XKEEN_DISABLE_BACKGROUND) {
    startFailoverWatchdog();
    startAutoFailoverWatchdog();
    subscriptions.start();
    routingSync.start();
    setTimeout(sweepGeoIpForConnections, 2000);
    // Only the installed Entware service performs housekeeping, never a development checkout.
    if(__dirname==='/opt/etc/xkeen-switcher') {
      const maintain=()=>{
        try {
          const storage=require('./lib/storage');
          storage.cleanupStages(DATA_DIR);
          const state=JSON.parse(fs.readFileSync(path.join(DATA_DIR,'update-status.json'),'utf8'));
          if(['complete','rolled_back'].includes(state.state)) storage.cleanupLegacy(__dirname);
        } catch {}
        try {require('./lib/storage').trimLog('/opt/var/log/xkeen-switcher.log');} catch {}
      };
      setTimeout(maintain,30000).unref();
      setInterval(maintain,60000).unref();
    }
  }
});
module.exports = { parseZipBuffer, evaluateServiceStatus, routingSync, server, loadData, saveData, parseVlessUrl, extractOutboundMetadata, measureConnectionHealth, subscriptions };
